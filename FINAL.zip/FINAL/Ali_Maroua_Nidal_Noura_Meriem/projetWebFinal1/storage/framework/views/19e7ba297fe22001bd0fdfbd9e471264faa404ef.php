<?php $__env->startSection('content'); ?>

    <div class="container">
    <h1>Creer une Annonce</h1>
    <br>
            <form action="<?php echo e(url('partenaire/createAnnonce')); ?>" method="post" class="form-group">
        <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">

            <label>Heure Debut</label>
            <input class="form-control" type="time" name="heure_Debut">
            <br>
            <label>Heure Fin</label>
            <input class="form-control" type="time" name="heure_fin">
            <br>
            <label>Voiture</label>
            <select class="form-control" name="id_voiture">

                <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?= $v['id'] ?>">
                        <?= $v['type']." "; ?> <?= $v['marque']?>
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <label>Prix</label>
            <input class="form-control" type="number" name="prix">
            <br>

        <input type="submit" value="Enregistrer" class="btn btn-success">
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb2/resources/views/partenaire/creerAnnonce.blade.php ENDPATH**/ ?>