<?php $__env->startSection('style'); ?>
    <style>
        .btn4{
            background-color: #ffc107;
            color: white;
        }
        .btn4:hover{
            color: #2a3342;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
body {
        background:#fafcfd;
      }
      .profile {
        margin: 20px 0;
      }
      .profile-sidebar {
        margin-top: 50px;
        height: 480px;
          width: 280px;
        padding: 20px 0 10px 0;
        background:lavender;
      }

      .profile-userpic img {
        float: none;
        margin: 0;
        width: 150px;
        height: 150px;
        border-radius: 50%;
      }

      .profile-usertitle {
        text-align: center;
        margin-top: 20px;
      }

      .profile-usertitle-name {
        color: #5a7391;
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 7px;
      }

      .profile-usertitle-job {
        text-transform: uppercase;
        color: #5b9bd1;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 15px;
      }


      /* Profile Content */
      .profile-content {
        margin-top: 50px;
          text-align: left;
        padding: 20px;
        background:lavender;
        min-height: 480px;
      }
    </style>
<div style="margin-top: 110px;"></div>
<div class="container">
        <div class="row profile">
            <div class="col-md-3">
                <div class="profile-sidebar">
                    <!-- SIDEBAR USERPIC -->
                    <center><div class="profile-userpic">
                            <img src="<?php echo e(asset('storage/'.$data->chemin_image)); ?>">
                    </div>
                    <!-- END SIDEBAR USERPIC -->
                    <!-- SIDEBAR USER TITLE -->
                    <div class="profile-usertitle">
                        <div class="profile-usertitle-name">
                               <h6><?php echo e($data->login); ?></h6>
                                <div class="profile-usertitle-job">
                                        <?php echo e($data->statut); ?>

                                    </div>
                                    <center><center><table>
                           <tr><td> Nom: </td><td><?php echo e($data->name); ?></td></tr>
                           <tr><td>CIN: </td><td><?php echo e($data->cin); ?></td></tr>
                           <tr><td>Tel:</td><td><?php echo e($data->tel); ?></td></tr>
                            <tr><td>Email: </td><td><?php echo e($data->email); ?></td></tr>
                               </table>

                        </div>

                    </div>
                    <!-- END SIDEBAR USER TITLE -->
                    <!-- SIDEBAR BUTTONS -->
                    <div class="profile-userbuttons">
                            <a href="/modifier" class="btn btn-danger btn-sm" >Modifier</a>
                    </div>
                    <!-- END SIDEBAR BUTTONS -->
                    <!-- SIDEBAR MENU -->

                    <!-- END MENU -->
                </div>
            </div>
            <div class="col-md-9">
                <div class="profile-content">
                        <h3>les commentaires sur mon profil</h3>
                        <p style="color:#5a7391"><?php echo e($comments->count()); ?> commentaires</p>
                        <hr>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <?php $who=\App\User::find($commentaire->id_from) ?>
                    <a style="color:blue;float:right;text-decoration:none" href="/whoComments/<?php echo e($who->id); ?>"><?php echo e($who->login); ?></a>
                            <p><span><?php echo e($commentaire->commentaire); ?></span></p>
                            <p>note:<span><?php echo e($commentaire->note); ?></span></p>
<hr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\projetWebMaroua\resources\views/profil.blade.php ENDPATH**/ ?>