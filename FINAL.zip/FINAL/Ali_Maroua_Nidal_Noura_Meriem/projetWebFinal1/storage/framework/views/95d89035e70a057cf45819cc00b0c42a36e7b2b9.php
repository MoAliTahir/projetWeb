<div style="height: 50px; background-color: #2a3342; position: fixed; top: 85px; width: 100%; z-index: 5">
    <div class="liens flex-center text-white">
        <a href="/home" class="bttn btn1">Accueil</a>|
        <a href="/profil" class="bttn btn2">Mon Profil</a>|
        <a href="/client/mesReservations" class="bttn btn3">Mes reservations</a>|
        <a href="/client/historique" class="bttn btn4">Historique</a>
    </div>
</div>
<?php /**PATH C:\wamp\www\projetWebFinal1\projetWebFinal1\resources\views/layouts/menuClient.blade.php ENDPATH**/ ?>