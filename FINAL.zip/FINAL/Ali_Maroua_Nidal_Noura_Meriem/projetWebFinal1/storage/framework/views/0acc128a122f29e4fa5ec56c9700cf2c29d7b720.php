<html>
 <head>
     <title><?php echo $__env->yieldContent('titre'); ?></title>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">

     <!-- CSRF Token -->
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <meta name="viewport" content="width=device-width, initial-scale=1">

     <title><?php echo e(config('app.name', 'Laravel')); ?></title>

     <!-- Scripts -->
     <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
     <script src="<?php echo e(asset('js/bootstrap.js')); ?>" defer></script>
     <!-- Fonts -->
     <link rel="dns-prefetch" href="//fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
     <link rel="icon" href="<?php echo e(asset('storage/images/logo2.png')); ?>">

     <!-- Styles -->
     <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
     <link href="<?php echo e(asset('css/test.css')); ?>" rel="stylesheet">
     <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

     <!-- Styles -->
     <style>
         html, body {
             background-color: #E2E1EB;
             color: #636b6f;
             font-family: 'Nunito', sans-serif;
             font-weight: 200;
             height: 100vh;
             margin: 0;
         }
             .aa{
                 width: 20px;
                 height: 20px;
                 margin-right: 4px;
                 margin-top: -4px;
             }
         .full-height {
             height: 100vh;
         }

         .flex-center {
             align-items: center;
             display: flex;
             justify-content: center;
         }

         .position-ref {
             position: relative;
         }

         .top-right {
             position: absolute;
             right: 10px;
             top: 18px;
         }

         .content {
             text-align: center;
         }

         .title {
             font-size: 84px;
         }

         .links > a {
             color: #636b6f;
             padding: 0 25px;
             font-size: 13px;
             font-weight: 600;
             letter-spacing: .1rem;
             text-decoration: none;
             text-transform: uppercase;
         }

         .m-b-md {
             margin-bottom: 30px;
         }
         #menu {
             position: fixed;
             left: 0;
             top: 60%;
             width: 8em;
             margin-top: -2.5em;
             z-index: 2;
             /*margin-left: 70px;*/
         }

         <?php echo $__env->yieldContent('style'); ?>
     </style>
 </head>
 <body>
 <main id="menu">

     <ul class="clearfix">

         <li><a href="#" class="btn"><span class="fontawesome-user"></span></a>

             <ul>

                 <li><a href="#"><span class="fontawesome-facebook" style="width: 30px;"></span></a></li>

                 <li><a href="#"><span class="fontawesome-twitter" style="width: 30px;"></span></a></li>

                 <li><a href="#"><span class="fontawesome-google-plus" style="width: 30px;"></span></a></li>

                 <li><a href="#"><span class="fontawesome-linkedin" style="width: 30px;"></span></a></li>

             </ul>

         </li>

     </ul>

 </main>


 <div id="app" style="background-color:#E2E1EB; ">
 <nav class="navbar navbar-expand-md navbar-light navbar-laravel " style="background-color: #321655; border-bottom: solid #E2E1EB 3px;  position: fixed;
  top: 0;
  height: 150px;
  width: 100%;
  z-index: 10;
  margin-top: -2.5em;">
     
     <img src="<?php echo e(asset('storage/images/logoFastEasy.png')); ?>" style="width: 200px; height: 100px; margin-left: 600px;" >
     <!-- Right Side Of Navbar -->
     <ul class="navbar-nav ml-auto">
         <!-- Authentication Links -->
         <?php if(auth()->guard()->guest()): ?>
             <li class="nav-item">
                 <a class="nav-link" href="<?php echo e(route('login')); ?>" style="color: white; margin-top: 20px;font-size: 20px;"><img class="aa" src="<?php echo e(asset('storage/images/user.png')); ?>" ><?php echo e(__('Se connecter')); ?></a>
             </li>
             <?php if(Route::has('register')): ?>
                 <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(route('register')); ?>" style="color: white;margin-top: 20px;font-size: 20px;"><img class="aa" src="<?php echo e(asset('storage/images/clipboard.png')); ?>" ><?php echo e(__("S'inscrire")); ?></a>
                 </li>
             <?php endif; ?>
         <?php else: ?>
             <li class="nav-item dropdown">
                 <a style="color: white;" id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                     <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                 </a>

                 <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                     <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                         <?php echo e(__('Se deconnecter')); ?>

                     </a>

                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                         <?php echo csrf_field(); ?>
                     </form>
                 </div>
             </li>
         <?php endif; ?>
     </ul>
 </nav>

               <div> <?php echo $__env->yieldContent('menu'); ?></div>

             <div class="container-fluid"> <?php echo $__env->yieldContent('content'); ?></div>

 </div>
     
 <footer>
     <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
     <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     <!------ Include the above in your HEAD tag ---------->

     <!-- Footer -->
     <section id="footer">
         <div class="container">
             <div class="row text-center text-xs-center text-sm-left text-md-left">
                 <div class="col-xs-12 col-sm-4 col-md-4">
                     <h5>Quick links</h5>
                     <ul class="list-unstyled quick-links">
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Home</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>About</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>FAQ</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Get Started</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Videos</a></li>
                     </ul>
                 </div>
                 <div class="col-xs-12 col-sm-4 col-md-4">
                     <h5>Quick links</h5>
                     <ul class="list-unstyled quick-links">
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Home</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>About</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>FAQ</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Get Started</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Videos</a></li>
                     </ul>
                 </div>
                 <div class="col-xs-12 col-sm-4 col-md-4">
                     <h5>Quick links</h5>
                     <ul class="list-unstyled quick-links">
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Home</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>About</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>FAQ</a></li>
                         <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Get Started</a></li>
                         <li><a href="https://wwwe.sunlimetech.com" title="Design and developed by"><i class="fa fa-angle-double-right"></i>Imprint</a></li>
                     </ul>
                 </div>
             </div>
             <div class="row">
                 <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
                     <ul class="list-unstyled list-inline social text-center">
                         <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
                         <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
                         <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
                         <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
                         <li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
                     </ul>
                 </div>
                 </hr>
             </div>
             <div class="row">
                 <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
                     <p><u><a href="https://www.nationaltransaction.com/">National Transaction Corporation</a></u> is a Registered MSP/ISO of Elavon, Inc. Georgia [a wholly owned subsidiary of U.S. Bancorp, Minneapolis, MN]</p>
                     <p class="h6">&copy All right Reversed.<a class="text-green ml-2" href="https://www.sunlimetech.com" target="_blank">Sunlimetech</a></p>
                 </div>
                 </hr>
             </div>
         </div>
     </section>
 </footer>

 </body>
</html><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWeb2\resources\views/layouts/publicTemplate.blade.php ENDPATH**/ ?>