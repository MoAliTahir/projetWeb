<?php $__env->startSection('menu'); ?>

    <div style="margin-top: 115px;  position: fixed;
  top: 150px;
  height: 150px;
  width: 100%;
  z-index: 10;
  margin-top: -2.5em;">

        <div class="cc">
            <nav>
                <center>
                    <a href="#" >Accueil</a>
                    <a href="<?php echo e(Route('Annonce')); ?>" >Mes Annonces</a>
                    <a href="<?php echo e(Route('listVoiture')); ?>">Mes voitures</a>
                    <a href="<?php echo e(Route('profil')); ?>">Mon profil</a>
                    <a href="#">mes notifications</a>
                    <a href="<?php echo e(Route('nouvelAnnonce')); ?>">creer une annonce</a>
                    <div class="animation start-home"></div>
                </center>
            </nav>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div style="margin-top: 160px;"></div>
    <div class="container">
    <h1>Creer une Annonce</h1>
   <a href="<?php echo e(url('partenaire/formVoiture')); ?>">  <button class="btn btn-success">Ajouter Voiture</button></a>
    <br>
            <form action="<?php echo e(url('partenaire/createAnnonce')); ?>" method="post" class="form-group">
        <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">


                <label>Ville</label>
                <select name="ville" class="form-control">
                    <option value="Agadir">Agadir</option>
                    <option value="Casablanca">Casablanca</option>
                    <option value="Rabat">Rabat</option>
                    <option value="Fes">Fes</option>
                    <option value="Sidi Kacem">Sidi Kacem</option>
                    <option value="Sale">Sale</option>
                    <option value="Tetouan">Tetouan</option>
                    <option value="Tanger">Tanger</option>
                    <option value="Rabat">Rabat</option>
                    <option value="Meknes">Meknes</option>
                    <option value="Essaouira ">Essaouira </option>
                    <option value="Dakhla">Dakhla</option>
                </select>
                <br>
                <label>DATE DE RETRAIT</label>
                <input class="form-control" type="date" name="date_debut">
                <br>
                <label>HEURE DE RETRAIT</label>
                <input class="form-control" type="time" name="heure_Debut">
                <br>
                <label>DATE DE RETOUR</label>
                <input class="form-control" type="date" name="date_fin">
                <br>
                <label>HEURE DE RETOUR</label>
                <input class="form-control" type="time" name="heure_fin">
                 <br>
                <label>Voiture</label>
                <select class="form-control" name="id_voiture">
                <option value="--">--</option>
                <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?= $v['id'] ?>">
                        <?= $v['type']." "; ?> <?= $v['marque']?>
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <label>Prix/Heure</label>
            <input class="form-control" type="number" name="prix">
            <br>

        <input type="submit" value="Enregistrer" class="btn btn-success">
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.publicTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\latestVersion3\projetWeb2\resources\views/partenaire/creerAnnonce.blade.php ENDPATH**/ ?>