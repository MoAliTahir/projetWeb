<?php $__env->startSection('style'); ?>
    <style>
        .btn3{
            background-color: #ffc107;
            color: white;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div style="margin-top: 160px;"></div>
    <div class="container" style="background-color:  #E2E1EB;">
    <h2 class="text-center">Vos annonces</h2>

      <a href="<?php echo e(Route('nouvelAnnonce')); ?>"><button class="btn btn-success" >creer une annonce</button></a>
    <br>
    <br>
        <div class="row" style="background-color:  #E2E1EB; ">
        <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $an): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 	$v=\App\Voiture::find($an->id_voiture) ?><!--selectionner les info de voiture a l'aide de cle etrangere qui est dans annonce -->
                <?php    $voiture_images2 = \App\Photo::all()->where("id_voiture", "=",$an->id_voiture)->first();?>

                    <div class="col-md-4">
                        <div class="card" style="width: 18rem;">
                                
                                
                                

                            <img src="<?php echo e(asset('storage/'.$voiture_images2->chemin)); ?>" class="card-img-bottom" alt="">
                                <div class="card-body">
                                    <h5 class="card-title text-dark"> <?= $v['marque']?> <?= $v['type']." "; ?> </h5>
                                    <div class="card-text" style="margin:20px">
                                        <table class="h6">
                                            <tr><td>Date de retrait :</td><td><?php echo e($an->date_debut); ?></td></tr>
                                            <tr><td>Heure de retrait :</td><td><?php echo e($an->heureDebut); ?></td></tr>
                                            <tr><td>Date de retour :</td><td><?php echo e($an->date_fin); ?></td></tr>
                                            <tr><td>Heure de retour :</td><td><?php echo e($an->heureFin); ?></td></tr>
                                            <tr class="text-danger"><td>Prix/heure :</td><td><?php echo e($an->prix); ?></td></tr>
                                        </table>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <a href="<?php echo e(url('partenaire/modifierAnnonce/'.$an->id)); ?>" class="btn btn-primary">Modifier</a>
                                            
                                            
                                            
                                        </div>
                                        <div class="col-6">
                                        <form action="<?php echo e(url('partenaire/suppressionAnnonce/'.$an->id)); ?>" method="post">
                                            <input type="hidden" name="_method" value="PUT">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="history" value="1">
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>

                                        </div>
                                    </div>

                                </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nidal version\latestVersion3\projetWeb2\resources\views/partenaire/mesAnnonces.blade.php ENDPATH**/ ?>