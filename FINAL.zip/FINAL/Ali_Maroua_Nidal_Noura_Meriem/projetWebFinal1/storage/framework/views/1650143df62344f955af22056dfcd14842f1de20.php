<html>
<head>
    <title><?php echo $__env->yieldContent('titre'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'FastEasy')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>" defer></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <link rel="icon" href="<?php echo e(asset('storage/images/logo2.png')); ?>">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/test.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <link href="<?php echo e(asset('storage/images/logoFastEasy.png')); ?>" rel="icon">

    <!-- Styles -->
    <style>
        html, body {
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
            bottom: 0;
        }


        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }
        .bttn:hover{
            color: #ffc107;
            text-decoration: none;

        }
        .liens > a{
            color: #ffffff;
            padding: 15px 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .links > a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
        #menu {
            position: fixed;
            left: 0;
            top: 60%;
            width: 8em;
            margin-top: -2.5em;
            z-index: 2;
            /*margin-left: 70px;*/
        }

    </style>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
<main id="menu">


</main>


<div id="app" style="background-color:#E2E1EB;">
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel " style="background-color: #2a3342; position: fixed;
  top: 0;
  height: 85px;
  width: 100%;
  z-index: 10;">
        
        <a href="/"><img src="<?php echo e(asset('storage/images/whiteLogoFastEasy.png')); ?>" style="width: 200px; height: 150px; margin-top: -10px;" ></a>
        <!-- Right Side Of Navbar -->
        <ul class="navbar-nav ml-auto">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('registerPartenaire')); ?>" style="color: white;margin-top: 10px;font-size: 15px;"><?php echo e(__("Devenir partenaire")); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>" style="color: white;margin-top: 10px;font-size: 15px;"><?php echo e(__("S'inscrire")); ?></a>
                    </li>

                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>" style="color: white; margin-top: 10px;font-size: 15px;"><?php echo e(__('Se connecter')); ?></a>
                </li>

            <?php else: ?>
                <li class="nav-item dropdown">
                    <a style="color: white;" id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" style="position: absolute; z-index: 20">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('Se deconnecter')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                
                 <?php if(Auth::user()->statut == "partenaire"): ?>
              <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                          <span class="glyphicon glyphicon-globe" style="margin-left:150px"></span><span style="color:white">Notifiations</span> <span class="badge text-white"><?php echo e(count(auth()->user()->unreadNotifications)); ?></span>
                            </a>

                           <ul class="dropdown-menu" role="menu" style="position: absolute; z-index: 0;" >
                            <li>
                                <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                 <?php echo $__env->make('layouts.notification.'.snake_case(class_basename($notification->type)), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p>Vous n'avez aucune notification</p>

                                    <?php endif; ?>
                            </li>
                             
                        </ul>
                            </div>
                        </li>
                        <?php endif; ?>
                         <?php if(Auth::user()->statut == "client"): ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                          <span class="glyphicon glyphicon-globe" style="margin-left:150px; color: white"></span>Notifiations <span class="badge text-white" ><?php echo e(count(auth()->user()->unreadNotifications)); ?></span>
                            </a>

                           <ul class="dropdown-menu" role="menu" style="position: absolute; z-index: 0;">
                            <li>
                                <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo $__env->make('layouts.notification.'.snake_case(class_basename($notification->type)), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                  
                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>
                             
                        </ul>
                            </div>
                        </li>
                         <?php endif; ?>
                <?php if(Auth::user()->statut == "admin"): ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <span class="glyphicon glyphicon-globe" style="margin-left:150px"></span><span style="color:white">Notifiations</span> <span class="badge text-white"><?php echo e(count(auth()->user()->unreadNotifications)); ?></span>
                        </a>

                        <ul class="dropdown-menu" role="menu" style="position: absolute; z-index: 0;" >
                            <li>
                                <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php echo $__env->make('layouts.notification.'.snake_case(class_basename($notification->type)), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p>Vous n'avez aucune notification</p>

                                <?php endif; ?>
                            </li>

                        </ul>
                        </div>
                    </li>
                    <?php endif; ?>

               
            <?php endif; ?>
        </ul>
    </nav>

    <?php echo $__env->yieldContent('menu'); ?>

    <?php echo $__env->yieldContent('content'); ?>

</div>



</body>
<?php echo $__env->make('layouts.footer2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebFinal1\resources\views/layouts/template.blade.php ENDPATH**/ ?>