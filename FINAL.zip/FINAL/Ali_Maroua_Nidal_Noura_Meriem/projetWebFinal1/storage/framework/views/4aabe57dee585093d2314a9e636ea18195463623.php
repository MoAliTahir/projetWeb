<?php $__env->startSection('menu'); ?>

    <div style="margin-top: 115px;  position: fixed;
  top: 150px;
  height: 150px;
  width: 100%;
  z-index: 10;
  margin-top: -2.5em;">

        <div class="cc">
                <nav>
                <center>
                    <a href="#" >Accueil</a>
                    <a href="<?php echo e(Route('Annonce')); ?>" >Mes Annonces</a>
                    <a href="<?php echo e(Route('listVoiture')); ?>">Mes voitures</a>
                    <a href="<?php echo e(Route('profil')); ?>">Mon profil</a>
                    <a href="#">mes notifications</a>
                    <a href="<?php echo e(Route('nouvelAnnonce')); ?>">creer une annonce</a>
                    <div class="animation start-home"></div>
                </center>
                    </nav>
            </div>


    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

         <?php
         $v=\App\Voiture::all();
         $ann= \App\Annonce::all()->where('history','=',0)->where('statut','=','disponible');//limiter le nombre d'annonce a 3 selon la date de creation
         $Par=\App\User::all();
         ?>
            <?php echo $__env->make('../welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/publicTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWeb2\resources\views/homePartenaire.blade.php ENDPATH**/ ?>