<?php $__env->startSection('style'); ?>
    <style>
        .btn3{
            background-color: #ffc107;
            color: white;
        }
        .btn3:hover{
            color: #2a3342;
        }
         /* style star*/

.clear{clear: both;}

.rate{
  width:225px; height: 40px;
  border:#e9e9e9 1px solid;
  background-color:  #f6f6f6;
  margin:60px auto;
  margin-bottom:0px;
}
.rate .rate-btn{
  width: 45px; height:40px;
  float: left;
  background: url("<?php echo e(asset('storage/images/rate-btn.png')); ?>") no-repeat;
  cursor: pointer;
}
.rate .rate-btn:hover, .rate  .rate-btn-hover, .rate  .rate-btn-active{
  background: url("<?php echo e(asset('storage/images/rate-btn-hover.png')); ?>") no-repeat;
}

.result-container{
  width: 82px; height: 18px;
  position: relative;
  background-color: #ccc;
  border: #ccc 1px solid;
  margin:auto;
}
.rate-stars{
  width: 82px; height: 18px;
  background-color:#ccc;
  background: url("<?php echo e(asset('storage/images/rate-stars.png')); ?>") no-repeat;
  position: absolute;
}
.rate-bg{
  height: 18px;
  background-color: #ffbe10;
  position: absolute;
}
/*fin style*/

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div style="margin-top: 160px;"></div>
    <div class="container">
        <h1>Mes voitures</h1>

        <br><br>

  <a href="<?php echo e(url('partenaire/formVoiture')); ?>">  <button class="btn btn-success">nouvelle voiture</button></a>

<div class="row">
        <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php    $voiture_images2 = \App\Photo::all()->where("id_voiture", "=",$v->id)->first();?>
                    <div class="col-md-4">
                        <div class="card shadow" style="width: 18rem;">
                            <img src="<?php echo e(asset('storage/'.$voiture_images2->chemin)); ?>" class="card-img-bottom" alt="">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">Type : <?php echo e($v->type); ?></h5>
                                                <!--noura-->
                    <img rel="icon" href="<?php echo e(asset('storage/images/note.png')); ?>">
      <div class="box-result">
      <?php
      $idClient=Auth::user()->id;

      $query= App\CommentaireVoiture::all()->where('id_to','=',$idClient);
            foreach($query  as $data)
            {
             $rate_db[] = $data;
             $sum_rates[] = $data->note;

            }
                if(@count($rate_db)){
                    $rate_times = count($rate_db);
                    $sum_rates = array_sum($sum_rates);
                    $rate_value = $sum_rates/$rate_times;
                    $rate_bg = (($rate_value)/5)*100;
                }else{
                    $rate_times = 0;
                    $rate_value = 0;
                    $rate_bg = 0;
                }
        ?>
    <div class="result-container">
      <div class="rate-bg" style="width:<?php echo $rate_bg; ?>%"></div>
        <div class="rate-stars"></div>
    </div>
        <p style="margin:5px 0px; font-size:16px; text-align:center">Rated <strong><?php echo substr($rate_value,0,3); ?></strong> out of <?php echo $rate_times; ?> Review(s)</p>
    </div>
                                    <div class="card-text" style="margin:20px">
                                        <table class="h6">
                                            <tr><td colspan="2"><img src="<?php echo e(asset('storage/images/users-group.png')); ?>" style="width: 20px; height: 20px;"> Nombre de palces :<?php echo e($v->nbr_places); ?></td></tr>
                                            <tr><td>Carburant:</td><td><?php echo e($v->carburant); ?></td></tr>
                                            <tr><td>Marque :</td><td><?php echo e($v->marque); ?></td></tr>
                                        </table>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <a href="<?php echo e(url('partenaire/modifierVoiture/'.$v->id)); ?>" class="btn btn-primary">Modifier</a>
                                        </div>
                                        <div class="col-6">
                                        <form action="<?php echo e(url('partenaire/suppressionVoiture/'.$v->id)); ?>" method="post">
                                            <input type="hidden" name="_method" value="PUT">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="history" value="1" >
                                                <button type="submit" class="btn btn-danger">Supprimer</button>
                                        </form>
                                        </div>
                                    </div>

                                </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
        <br><br>


        
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projetWebFinal1\resources\views/partenaire/mesVoitures.blade.php ENDPATH**/ ?>