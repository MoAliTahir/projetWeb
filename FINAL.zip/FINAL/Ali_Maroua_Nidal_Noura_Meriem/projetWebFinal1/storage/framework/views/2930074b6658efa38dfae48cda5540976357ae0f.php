<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .btn1{
            background-color: #ffc107;
            color: white;
        }
        .btn1:hover{
            color: #2a3342;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
    $v=\App\Voiture::all();
    $ann= \App\Annonce::all()->where('history','=',0)->where('statut','=','disponible');//limiter le nombre d'annonce a 3 selon la date de creation
    $Par=\App\User::all();
    ?>

    <?php echo $__env->make('../welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/FINAL/projetWebFinal1/resources/views/homeClient.blade.php ENDPATH**/ ?>