<?php $__env->startSection('content'); ?>

          
          
          
          
          
          
             
          
          
          
             
          
    

          <div class="col-md-4">
              <div class="card" style="width: 18rem;">
                  <img src="<?php echo e(asset('storage/'.$v->chemin_image)); ?>" class="card-img-bottom" alt="">
                  <div class="card-body">
                      <h5 class="card-title text-dark"> <?= $v['marque']?> <?= $v['type']." "; ?> </h5>
                      <div class="card-text" style="margin:20px">
                          <table class="h6">
                              <tr><td>Date de retrait :</td><td><?php echo e($an->date_debut); ?></td></tr>
                              <tr><td>Heure de retrait :</td><td><?php echo e($an->heureDebut); ?></td></tr>
                              <tr><td>Date de retour :</td><td><?php echo e($an->date_fin); ?></td></tr>
                              <tr><td>Heure de retour :</td><td><?php echo e($an->heureFin); ?></td></tr>
                              <tr class="text-danger"><td>Prix/heure :</td><td><?php echo e($an->prix); ?></td></tr>
                          </table>
                      </div>
                  </div>
              </div>
          </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWeb2\resources\views/client/voirAnnonce.blade.php ENDPATH**/ ?>