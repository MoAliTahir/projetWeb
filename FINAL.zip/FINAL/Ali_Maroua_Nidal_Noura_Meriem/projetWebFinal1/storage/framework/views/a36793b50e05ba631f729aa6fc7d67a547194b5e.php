<a href="/whoComments/<?php echo e($notification->data['reservation']['id_client']); ?>">Nouvelle reservation :</a>
<a href="/confirmer/<?php echo e($notification->data['reservation']['id']); ?>">confirmer</a>
<a href="">annuler</a><?php /**PATH C:\wamp64\www\latestVersion3\projetWeb2\resources\views/layouts/notification/notify_reser.blade.php ENDPATH**/ ?>