<?php if(Auth::user()->statut == "admin"): ?>
    <p> </p>
    <a class="dropdown-item" href="/whoComments/<?php echo e($notification->data['Signalisation']['id_to']); ?>">le compte Signaler :</a>

<?php endif; ?>
<?php /**PATH C:\wamp\www\projetWebMeryem\resources\views/layouts/notification/notify_signaler.blade.php ENDPATH**/ ?>