



<div class="col-md-9">
    <div class="profil-content">
           <p>de :<a href="/whoComments/<?php echo e($userfrom->id); ?>"><?php echo e($userfrom->login); ?></a><br></p>
             <p>son commentaire: <?php echo e($commentaire->avisNegative); ?><br><?php echo e($commentaire->avisPositive); ?></p>
            <p> a : <a href="/whoComments/<?php echo e($userfrom->id); ?>"><?php echo e($userto->login); ?> </a></p><br>
            <br> <a href="/SupprimerCommentaire/<?php echo e($commentaire->id); ?>" class="btn btn-danger" >Supprimer</a>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/Laravel/FINAL/projetWebFinal1/resources/views/commentaireSignaler.blade.php ENDPATH**/ ?>