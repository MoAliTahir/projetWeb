<?php $__env->startSection('content'); ?>
            <div class="content">
                    <div class="title m-b-md">
                        Espase Partenaire
                    </div>

                    <div class="links">
                        <a href="<?php echo e(Route('Annonce')); ?>">Mes Annonces</a>
                        <a href="<?php echo e(Route('listVoiture')); ?>">Mes voitures</a>
                        <a href="<?php echo e(Route('profil')); ?>">Mon profil</a>
                        <a href="#">mes notifications</a>
                        <a href="<?php echo e(Route('nouvelAnnonce')); ?>">creer une annonce</a>
                    </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb2/resources/views/homePartenaire.blade.php ENDPATH**/ ?>