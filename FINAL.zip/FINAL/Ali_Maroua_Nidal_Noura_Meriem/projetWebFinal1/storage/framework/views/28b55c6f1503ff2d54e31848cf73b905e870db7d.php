<html>
 <head>
     <title><?php echo $__env->yieldContent('titre'); ?></title>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">

     <!-- CSRF Token -->
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <meta name="viewport" content="width=device-width, initial-scale=1">

     <title><?php echo e(config('app.name', 'Laravel')); ?></title>

     <!-- Scripts -->
     <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
     <script src="<?php echo e(asset('js/bootstrap.js')); ?>" defer></script>
     <!-- Fonts -->
     <link rel="dns-prefetch" href="//fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

     <!-- Styles -->
     <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
     <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

     <!-- Styles -->
     <style>
         html, body {
             background-color: #E2E1EB;
             color: #636b6f;
             font-family: 'Nunito', sans-serif;
             font-weight: 200;
             height: 100vh;
             margin: 0;
         }
             .aa{
                 width: 20px;
                 height: 20px;
                 margin-right: 4px;
                 margin-top: -4px;
             }
         .full-height {
             height: 100vh;
         }

         .flex-center {
             align-items: center;
             display: flex;
             justify-content: center;
         }

         .position-ref {
             position: relative;
         }

         .top-right {
             position: absolute;
             right: 10px;
             top: 18px;
         }

         .content {
             text-align: center;
         }

         .title {
             font-size: 84px;
         }

         .links > a {
             color: #636b6f;
             padding: 0 25px;
             font-size: 13px;
             font-weight: 600;
             letter-spacing: .1rem;
             text-decoration: none;
             text-transform: uppercase;
         }

         .m-b-md {
             margin-bottom: 30px;
         }
     </style>
 </head>
 <body>
 <div id="app">
 <nav class="navbar navbar-expand-md navbar-light navbar-laravel " style="background-color: #321655; margin-bottom: 20px; position: fixed;
  top: 0;
  height: 150px;
  width: 100%;
  z-index: 10;
  margin-top: -2.5em;">
     
     <img src="<?php echo e(asset('storage/images/logoFastEasy.png')); ?>" style="width: 200px; height: 100px; margin-left: 600px;" >
     <!-- Right Side Of Navbar -->
     <ul class="navbar-nav ml-auto">
         <!-- Authentication Links -->
         <?php if(auth()->guard()->guest()): ?>
             <li class="nav-item">
                 <a class="nav-link" href="<?php echo e(route('login')); ?>" style="color: white; margin-top: 20px;font-size: 20px;"><img class="aa" src="<?php echo e(asset('storage/images/user.png')); ?>" ><?php echo e(__('Se connecter')); ?></a>
             </li>
             <?php if(Route::has('register')): ?>
                 <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(route('register')); ?>" style="color: white;margin-top: 20px;font-size: 20px;"><img class="aa" src="<?php echo e(asset('storage/images/clipboard.png')); ?>" ><?php echo e(__("S'inscrire")); ?></a>
                 </li>
             <?php endif; ?>
         <?php else: ?>
             <li class="nav-item dropdown">
                 <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                     <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                 </a>

                 <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                     <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                         <?php echo e(__('Logout')); ?>

                     </a>

                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                         <?php echo csrf_field(); ?>
                     </form>
                 </div>
             </li>
         <?php endif; ?>
     </ul>
 </nav>

             <?php echo $__env->yieldContent('content'); ?>

 </div>
 </body>
</html><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWeb2\resources\views/layouts/publicTemplate.blade.php ENDPATH**/ ?>