<?php $__env->startSection('style'); ?>
    <style>
        .btn1{
            background-color: #ffc107;
            color: white;
        }
        .btn1:hover{
            color: #2a3342;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div style="margin-top: 160px;"></div>
    <div class="container" style="background-color:  #E2E1EB;">

        <?php

        if (isset($message)):
        ?>
        <script>
            alert("Reservation confirmer avec succes")
        </script>

            <?php
            endif;
            ?>


    <h2 class="text-center">Bienvenue dans votre espace</h2>

      <a href="<?php echo e(Route('nouvelAnnonce')); ?>"><button class="btn btn-success" >creer une annonce</button></a>
    <br>
    <br>

        <h4>Liste des annonces</h4><br>
        <div class="row" style="background-color:  #E2E1EB; ">
        <?php $__empty_1 = true; $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $an): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php 	$v=\App\Voiture::find($an->id_voiture) ?><!--selectionner les info de voiture a l'aide de cle etrangere qui est dans annonce -->
                <?php    $voiture_images2 = \App\Photo::all()->where("id_voiture", "=",$an->id_voiture)->first();?>

                <div class="col-md-4" style="width:500px;
    height:500px;
    position:relative;
    overflow: hidden;">
                        <div class="card" style="width: 24rem;">
                                
                                
                                

                            <img src="<?php echo e(asset('storage/'.$voiture_images2->chemin)); ?>" class="card-img-bottom" alt="">
                                <div class="card-body">
                                <?php if($an->statut=='reservé'): ?>
        <div style="background-color:#fbb100;
    width:200px;
    height:200px;
    position:absolute;
    top:-100px;
    right:-100px;
    -webkit-transform:rotate(45deg);"></div>
        <div style="color:#FFF;
    -webkit-transform:rotate(45deg);
    font-size:20px;
    position:absolute;
    top:35px;
    right:15px;">Reserver</div>
    <?php endif; ?>
                                    <h5 class="card-title text-dark"> <?= $v['marque']?> <?= $v['type']." "; ?> </h5>
                                    <div class="card-text" style="margin:20px">
                                        <table class="h6">
                                            <tr><td>Date de retrait :</td><td><?php echo e($an->date_debut); ?></td></tr>
                                            <tr><td>Heure de retrait :</td><td><?php echo e($an->heureDebut); ?></td></tr>
                                            <tr><td>Date de retour :</td><td><?php echo e($an->date_fin); ?></td></tr>
                                            <tr><td>Heure de retour :</td><td><?php echo e($an->heureFin); ?></td></tr>
                                            <tr class="text-danger"><td>Prix/heure :</td><td><?php echo e($an->prix); ?></td></tr>
                                        </table>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <a href="<?php echo e(url('partenaire/modifierAnnonce/'.$an->id)); ?>" class="btn btn-primary">Modifier</a>
                                            
                                            
                                            
                                        </div>
                                        <div class="col-6">
                                        <form action="<?php echo e(url('partenaire/suppressionAnnonce/'.$an->id)); ?>" method="post">
                                            <input type="hidden" name="_method" value="PUT">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="history" value="1">
                                                <button type="submit" class="btn btn-danger">Supprimer</button>
                                        </form>

                                        </div>
                                    </div>

                                </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <div class="col-md-12">
                        <p class="h5">Vous n'avez creer aucune annonces.. creer une</p><br><br><br><br><br><br>
                    </div>

            <?php endif; ?>
                </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projetWebFinal1\resources\views/partenaire/mesAnnonces.blade.php ENDPATH**/ ?>