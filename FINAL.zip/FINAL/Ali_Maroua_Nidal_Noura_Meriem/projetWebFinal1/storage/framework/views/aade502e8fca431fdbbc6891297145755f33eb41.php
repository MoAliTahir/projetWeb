    
        
            
        

        
            
            
            
            
            
        
    








<?php $__env->startSection('style'); ?>

    .cc nav {

    position: relative;
    width:100%;
    height: 50px;
    background-color:#321655;
    font-size: 0;
    }
    .cc nav a {
    line-height: 50px;
    height: 100%;
    font-size: 15px;
    display: inline-block;
    position: relative;
    z-index: 1;
    text-decoration: none;
    text-transform: uppercase;
    text-align: center;
    color: white;
    cursor: pointer;
    }
    .cc .animation {
    position: absolute;
    height: 100%;
    top: 0;
    z-index: 0;
    transition: all .5s ease 0s;
    border-radius: 8px;
    }
    .cc a:nth-child(1) {
    width: 170px;
    }
    .cc a:nth-child(2) {
    width: 170px;
    }
    .cc a:nth-child(3) {
    width: 170px;
    }
    .cc a:nth-child(4) {
    width: 170px;
    }
    .cc a:nth-child(5) {
    width: 170px;
    }
    .cc a:nth-child(6) {
    width: 170px;
    }
    .cc nav .start-home, a:nth-child(1):hover~.animation {
    width: 170px;
    left: 0;
    background-color: #1abc9c;
    margin-left: 330px;
    }
    .cc nav .start-about, a:nth-child(2):hover~.animation {
    width: 170px;
    left: 170px;
    background-color: #e74c3c;
    }
    .cc nav .start-blog, a:nth-child(3):hover~.animation {
    width: 170px;
    left: 340px;
    background-color: #3498db;
    }
    .cc nav .start-portefolio, a:nth-child(4):hover~.animation {
    width: 170px;
    left: 510px;
    background-color: #9b59b6;
    }
    .cc nav .start-portefolio, a:nth-child(5):hover~.animation {
    width: 170px;
    left: 680px;
    background-color: greenyellow;
    }
    .cc nav .start-contact, a:nth-child(6):hover~.animation {
    width: 170px;
    left: 850px;
    background-color: #e67e22;
    }
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>

    <div style="margin-top: 115px;  position: fixed;
  top: 150px;
  height: 150px;
  width: 100%;
  z-index: 10;
  margin-top: -2.5em;
">
        <div class="cc">
            <nav>
                <center>
                    <a href="" >Accueil</a>
                    <a href="/profil">Mon Profil</a>
                    <a href="client/mesReservations">Mes reservations</a>
                    <a href="#">mes notifications</a>
                    <div class="animation start-home"></div>
                </center>
            </nav>
        </div>


    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
    $v=\App\Voiture::all();
    $ann= \App\Annonce::all()->where('history','=',0)->where('statut','=','disponible');//limiter le nombre d'annonce a 3 selon la date de creation
    $Par=\App\User::all();
    ?>
    <?php echo $__env->make('../welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/publicTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\latestVersion3\projetWeb2\resources\views/homeClient.blade.php ENDPATH**/ ?>