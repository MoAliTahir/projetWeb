<?php $__env->startSection('style'); ?>
    <style>
        .btn3{
            background-color: #ffc107;
            color: white;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 150px;margin-bottom: 150px;">
        <h1>Mes reservations / nombre <?php echo e($data->count()); ?></h1>

        <table>
            <tr>
                <th>Date de reservation</th>
                <th>Voir annonce</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><span><?php echo e($resev->created_at); ?></span></td>
                    <td><a href="mesReservations/voirAnnonce/<?php echo e($resev->id_annonce); ?>"><button class="btn-success btn">VOIR</button> </a></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nidal version\latestVersion3\projetWeb2\resources\views/client/mesReservations.blade.php ENDPATH**/ ?>