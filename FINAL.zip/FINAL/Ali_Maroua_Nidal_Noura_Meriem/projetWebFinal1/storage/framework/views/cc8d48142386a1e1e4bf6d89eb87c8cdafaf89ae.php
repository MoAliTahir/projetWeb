<?php if(Auth::user()->statut == "partenaire"): ?>

    <?php
        $client = \App\User::find($notification->data['reservation']['id_client']);
    ?>


        <?php if($notification->url != null): ?>
            <a  class="dropdown-item" href="<?php echo e($notification->url); ?>">Veuillez evaluer<strong><?php echo e($client->login); ?></strong></a>
        <?php else: ?>
            <a  class="dropdown-item" href="/whoComments/<?php echo e($notification->data['reservation']['id_client']); ?>">Demande de reservation: <strong><?php echo e($client->login); ?></strong></a>
            <a class="dropdown-item" onclick="markAsRead('<?php echo e($notification->id); ?>')" href="/confirmer/<?php echo e($notification->data['reservation']['id']); ?>/<?php echo e($notification->data['reservation']['id_annonce']); ?>" name="confimer">confirmer</a>
            <a  class="dropdown-item" onclick="markAsRead('<?php echo e($notification->id); ?>')" href="#">Annuler</a>
        <?php endif; ?>
<?php endif; ?>
<?php if(Auth::user()->statut == "client"): ?>
    <a href="/consulterAnnonce/<?php echo e($notification->data['reservation']['id_annonce']); ?>" class="dropdown-item" onclick="markAsRead('<?php echo e($notification->id); ?>')">
        Felicitaion, votre reservation N°<?php echo e($notification->data['reservation']['id']); ?> est confirmé
    </a>
<?php endif; ?>

<?php /**PATH /opt/lampp/htdocs/Laravel/FINAL/projetWebFinal1/resources/views/layouts/notification/notify_reser.blade.php ENDPATH**/ ?>