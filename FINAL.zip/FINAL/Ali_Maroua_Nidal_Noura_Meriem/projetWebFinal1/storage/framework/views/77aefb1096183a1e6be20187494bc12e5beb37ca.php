<?php if(Auth::user()->statut == "admin"): ?>
    <p> </p>
    <a href="/CommentaireSignaler/<?php echo e($notification->data['Signalisation']['id_to']); ?>">le commentaire Signaler :</a>

<?php endif; ?>
<?php /**PATH C:\wamp\www\projetWebMeryem\resources\views/layouts/notification/notify_sinaler_c.blade.php ENDPATH**/ ?>