<?php $__env->startSection('content'); ?>


    <img src="<?php echo e(asset('storage/'.$v->chemin_image)); ?>" class="card-img-bottom"  style="width: 200px ; height: 200px;" alt="">
        <table>

            <tr><td>marque :</td><td><?php echo e($v->marque); ?></td></tr>
            <tr><td>type :</td><td><?php echo e($v->type); ?></td></tr>
            <tr><td>Carburant :</td><td><?php echo e($v->carburant); ?></td></tr>
            <tr><td>Nombre de places :</td><td><?php echo e($v->nbr_places); ?></td></tr>
            <tr><td>prix/Heure :</td><td><?php echo e($an1->prix); ?></td></tr>
        </table>

           <p> Date de retrait <?php echo e($an1->date_debut); ?></p>
            <p> Heure de Retrait<?php echo e($an1->heureDebut); ?></p>
            <p> Date de retour <?php echo e($an1->date_fin); ?></p>
            <p> Heure de retour<?php echo e($an1->heureFin); ?></p>

        <!--<a href=''>Consulter Annonce</a> <a href='/ProfilPartenaire'><?php echo e($P->login); ?></a> origin-->
        



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWeb2\resources\views/consulterAnnonce.blade.php ENDPATH**/ ?>