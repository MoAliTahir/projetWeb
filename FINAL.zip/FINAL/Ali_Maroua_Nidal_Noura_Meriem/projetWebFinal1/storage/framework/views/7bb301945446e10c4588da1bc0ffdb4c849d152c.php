<?php $__env->startSection('content'); ?>
    <div class="container">
            <form action="<?php echo e(url('partenaire/modifierAnnonce/'.$annonce->id)); ?>" method="post" class="form-group">
            <input type="hidden" name="_method" value="PUT">
            <?php echo e(csrf_field()); ?>

            <label>heureDebut</label>
            <input class="form-control" type="time" name="heureDebut" value="<?php echo e($annonce->heureDebut); ?>">
            <br>
            <label>heureFin</label>
            <input class="form-control" type="time" name="heureFin" value="<?php echo e($annonce->heureFin); ?>">
            <br>
            <label>prix</label>
            <input class="form-control" type="number" name="prix" value="<?php echo e($annonce->prix); ?>">
            <br>
            <label>statut</label>
            <input class="form-control" type="text" name="statut" value="<?php echo e($annonce->statut); ?>">
            <br>
            <select name="id_voiture" class="form-control">

                <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($v['id'] == $annonce->id_voiture) { ?>
                    <option value="<?= $v['id'] ?>" selected>
                        <?= $v['type']." "; ?> <?= $v['marque']?>
                    </option>
                        <?php }  else {?>
                        <option value="<?= $v['id'] ?>">
                        <?= $v['type']." "; ?> <?= $v['marque']?>
                            <?php } ?>
                        </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <input type="submit" value="Enregistrer" class="btn btn-success">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\projetWeb2\resources\views/partenaire/modifierAnnonce.blade.php ENDPATH**/ ?>