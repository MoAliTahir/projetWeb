<div style="height: 50px; background-color: #2a3342; position: fixed; top: 85px; width: 100%; z-index: 5">
    <div class="liens flex-center text-white">

        <a href="/profil" class="bttn btn2">Mon Profil</a>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebFinal1\resources\views/layouts/menuAdmin.blade.php ENDPATH**/ ?>