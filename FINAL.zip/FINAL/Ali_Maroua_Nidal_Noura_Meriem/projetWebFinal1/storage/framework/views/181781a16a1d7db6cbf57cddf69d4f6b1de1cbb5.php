<?php $__env->startSection('style'); ?>
    <style>
        .btn5{
            background-color: #ffc107;
            color: white;
        }
        .btn5:hover{
            color: #2a3342;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div style="margin-top: 135px;padding-top: 20px; background-color: #E2E1EB ; ">
    <div class="container"  >

   <a href="<?php echo e(url('partenaire/formVoiture')); ?>">  <button class="btn btn-success" style="float: right;">Ajouter Voiture</button></a>
    <br>
            <div class="row" style="height: 100%;">
        <div class="col-md-3" ></div>
        <div class="col-md-6">
            <form action="<?php echo e(url('partenaire/createAnnonce')); ?>" method="post" class="form-group">
        <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">


                <label style="font-weight: 800;">Ville</label>
                <select name="ville" class="form-control">
                    <option value="Agadir">Agadir</option>
                    <option value="Casablanca">Casablanca</option>
                    <option value="Rabat">Rabat</option>
                    <option value="Fes">Fes</option>
                    <option value="Sidi Kacem">Sidi Kacem</option>
                    <option value="Sale">Sale</option>
                    <option value="Tetouan">Tetouan</option>
                    <option value="Tanger">Tanger</option>
                    <option value="Rabat">Rabat</option>
                    <option value="Meknes">Meknes</option>
                    <option value="Essaouira ">Essaouira </option>
                    <option value="Dakhla">Dakhla</option>
                </select>
                <br>
                <label  style="font-weight: 800;" >DATE DE RETRAIT</label>
                <input class="form-control from-control-sm" type="date" name="date_debut">
                <br>
                <label  style="font-weight: 800;">HEURE DE RETRAIT</label>
                <input class="form-control from-control-sm"  type="time" name="heure_Debut">
                <br>
                <label  style="font-weight: 800;">DATE DE RETOUR</label>
                <input class="form-control from-control-sm" type="date" name="date_fin">
                <br>
                <label  style="font-weight: 800;">HEURE DE RETOUR</label>
                <input class="form-control from-control-sm" type="time" name="heure_fin">
                 <br>
                <label  style="font-weight: 800;">Voiture</label>
                <select class="form-control from-control-sm" name="id_voiture">
                <option value="--">--</option>
                <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?= $v['id'] ?>">
                        <?= $v['type']." "; ?> <?= $v['marque']?>
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <label  style="font-weight: 800;">Prix/Heure</label>
            <input class="form-control from-control-sm" type="number" name="prix">
            <br>

        <input type="submit" value="Enregistrer" class="btn btn-success">
        </form>
        </div>
            </div>
        <br><br><br>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebFinal1\resources\views/partenaire/creerAnnonce.blade.php ENDPATH**/ ?>