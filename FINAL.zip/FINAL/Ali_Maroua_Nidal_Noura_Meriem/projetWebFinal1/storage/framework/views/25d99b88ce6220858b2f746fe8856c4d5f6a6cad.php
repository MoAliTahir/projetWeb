

<?php $__env->startSection('content'); ?>
    <h1>Mon Profil</h1>

    <img src="<?php echo e($data->chemin_image); ?>">

    <p>Nom: <span><?php echo e($data->name); ?></span> </p>
    <p>Email: <span><?php echo e($data->email); ?></span> </p>
    <p>Telf: <span><?php echo e($data->tel); ?></span> </p>
    <p>cin: <span><?php echo e($data->cin); ?></span> </p>
    <p>login: <span><?php echo e($data->login); ?></span> </p>


    <a href="/modifier" class="btn btn-danger" >Modifier</a>

    <h1>les commentaires sur mon profil</h1>
    <h3>il y a <?php echo e($comments->count()); ?> commentaires</h3>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <hr>

        <?php $who=\App\User::find($commentaire->id_from) ?>
        <p>login:<?php echo e($who->login); ?></p>
        <p><a href="/whoComments/<?php echo e($who->id); ?>">lien vers son profils</a></p>

        <p>contenu : <span><?php echo e($commentaire->commentaire); ?></span></p>
        <p>note:<span><?php echo e($commentaire->note); ?></span></p>

        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script src="<?php echo e(asset('assets/js/bootstrap.min.js ')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb2/resources/views/profil.blade.php ENDPATH**/ ?>