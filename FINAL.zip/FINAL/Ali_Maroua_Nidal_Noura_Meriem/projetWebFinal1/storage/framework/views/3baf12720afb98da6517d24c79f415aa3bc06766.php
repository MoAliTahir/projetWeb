<?php $__env->startSection('style'); ?>
    <style>
        .btn4{
            background-color: #ffc107;
            color: white;
        }
        .btn4:hover{
            color: #2a3342;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="height: 100%; margin-top: 150px;">
      <h2>LES COMMENTAIRES SUR LES VOITURES</h2>
        <table class="table">
            <tr>
                <th>Partenaire</th>
                <th>Voiture</th>
                <th>Contenu</th>
                <th>Date Commentaire</th>
            </tr>

        <?php $__currentLoopData = $comments1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $voiture = \App\Voiture::find($comm1->id_to);
                  $partenaire=\App\User::find($voiture->id_partenaire);
            ?>

              <tr>

                  <td>
                      <a style="  text-decoration:none ; " href='/whoComments/<?php echo e($partenaire->id); ?>'>
                          <img border-radius="50%" width="20%" style=" width: 30px; height: 30px;"  src="<?php echo e(asset('storage/'.$partenaire->chemin_image)); ?>">
                      </a>
                      <a style="color:blue;text-decoration:none" href="/whoComments/<?php echo e($partenaire->id); ?>"><?php echo e($partenaire->login); ?></a>
                  </td>
                  <td><a href=""><?php echo e($voiture->marque); ?> <?php echo e($voiture->type); ?></a></td>
                  <td>
                      <p>   <img  src="<?php echo e(asset('storage/images/happy.png')); ?>" style="width: 20px; height: 20px;"><span><?php echo e($comm1->avisPositive); ?></span></p>
                      <p>   <img  src="<?php echo e(asset('storage/images/sad.png')); ?>" style="width: 20px; height: 20px;"><span><?php echo e($comm1->avisNegative); ?></span></p>
                  </td>
                  <td><?php echo e($comm1->created_at); ?></td>
              </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      <hr>
      <h2>LES COMMENTAIRES SUR LES PARTEANIRES</h2>
        <table class="table">
            <tr>
                <th>Partenaire</th>
                <th>Contenu</th>
                <th>Date Commentaire</th>
            </tr>

            <?php $__currentLoopData = $comments2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                      $partenaire=\App\User::find($comm1->id_to);
                ?>

                <tr>

                    <td>
                        <a style="  text-decoration:none ; " href='/whoComments/<?php echo e($partenaire->id); ?>'>
                            <img border-radius="50%" width="20%" style=" width: 30px; height: 30px;"  src="<?php echo e(asset('storage/'.$partenaire->chemin_image)); ?>">
                        </a>
                        <a style="color:blue;text-decoration:none" href="/whoComments/<?php echo e($partenaire->id); ?>"><?php echo e($partenaire->login); ?></a>
                    </td>

                    <td>
                        <p>   <img  src="<?php echo e(asset('storage/images/happy.png')); ?>" style="width: 20px; height: 20px;"><span><?php echo e($comm1->avisPositive); ?></span></p>
                        <p>   <img  src="<?php echo e(asset('storage/images/sad.png')); ?>" style="width: 20px; height: 20px;"><span><?php echo e($comm1->avisNegative); ?></span></p>
                    </td>
                    <td><?php echo e($comm1->created_at); ?></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebFinal1\resources\views//client/historique.blade.php ENDPATH**/ ?>