<?php $__env->startSection('content'); ?>
            <div class="content">
                    <div class="title m-b-md">
                        Espase Administrateur
                    </div>

                    <div class="links">
                        <a href="#">Page1</a>
                        <a href="#">Page2</a>
                        <a href="#">MPAge3</a>
                        <a href="#">mes notifications</a>
                        <a href="#">Page4</a>
                    </div>
            </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb/resources/views/homeAdmin.blade.php ENDPATH**/ ?>