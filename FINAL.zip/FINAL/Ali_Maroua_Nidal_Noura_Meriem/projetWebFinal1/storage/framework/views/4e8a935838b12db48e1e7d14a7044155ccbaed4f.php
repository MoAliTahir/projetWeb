<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1>Ajouter une nouvelle voiture</h1>

        <br><br>

        <form action="<?php echo e(url('partenaire/createVoiture')); ?>" method="post"  enctype="multipart/form-data" class="form-group">
            <?php echo e(csrf_field()); ?>


            <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
            <label>Type</label>

                <select name="type" class="form-control">
                    <option value="Coupé">Coupe</option>
                    <option value="Familiale">Familiale</option>
                    <option value="Cabriolet">Cabriolet</option>
                    <option value="Pickup">Pickup</option>
                </select>
            <br>
            <label>Marque</label>
            <input type="text" name="marque" class="form-control">
            <label>Modele</label>
            <br>
            <input type="text" name="modele" class="form-control">
            <br>
            <label>Choisir une image</label>
            <input type="file" name="image" class="form-control">

            <br>
            <input type="submit" value="Créer" class="btn btn-success">
        </form>
    <br><br>
<h2>Vos voitures</h3>
        

<div class="row">
        <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card" style="width: 18rem;">
                            <img src="<?php echo e(asset('storage/'.$v->chemin_image)); ?>" class="card-img-bottom" alt="">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">Type : <?php echo e($v->type); ?></h5>
                                    <div class="card-text" style="margin:20px">
                                        <table class="h6">		
                                            <tr><td>Modele :</td><td><?php echo e($v->modele); ?></td></tr>
                                            <tr><td>Marque :</td><td><?php echo e($v->marque); ?></td></tr>
                                        </table>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <a href="<?php echo e(url('Voiture/'.$v->id.'/edit')); ?>" class="btn btn-primary">Modifier</a>
                                        </div>
                                        <div class="col-6">
                                        <form action="<?php echo e(url('Voiture_delete/'.$v->id)); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <button type="submit" class="btn btn-danger">Supprimer</button>
                                        </form>
                                        </div>
                                    </div>

                                </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>


        
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb2/resources/views/partenaire/mesVoitures.blade.php ENDPATH**/ ?>