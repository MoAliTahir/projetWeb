<footer class="footer mt-auto py-3" style="background-color: #0f6674; bottom: 0;">
    <div class="container">
        <span class="text-muted">Place sticky footer content here.</span>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebFinal1\resources\views/layouts/footer2.blade.php ENDPATH**/ ?>