<?php if(Auth::user()->statut == "admin"): ?>

    <?php
        $user = \App\User::find($notification->data['Signalisation']['id_from'])
    ?>
    <a class="dropdown-item" onclick="markAsRead('<?php echo e($notification->id); ?>')" href="/CommentaireSignaler/<?php echo e($notification->data['Signalisation']['id_to']); ?>">
        Commentaire signalé par: <strong><?php echo e($user->login); ?></strong>
    </a>
    <hr>

<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/Laravel/FINAL/projetWebFinal1/resources/views/layouts/notification/notify_sinaler_c.blade.php ENDPATH**/ ?>