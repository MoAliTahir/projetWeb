<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php if(\Illuminate\Support\Facades\Auth::user()->statut=='client'): ?>
        <?php echo $__env->make('layouts.menuClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Auth::user()->statut=='partenaire'): ?>
        <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Auth::user()->statut=='admin'): ?>
        <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div style="background-color:  #E2E1EB; height: 100%; margin-top: 135px; padding-top: 30px;">
<div class="container form-group">

    <h2 style="margin-left: 100px;">Modifier Profil</h2><br>
<form method="post" action="/update" enctype="multipart/form-data" style="margin-left: 100px;">

    <input type="hidden" name="_method" value="PUT">

    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-md-3">
   <label style="font-weight: 800;"> <b>login</b> </label><input type="text" class="form-control"  name="login" value="<?php echo e($data->login); ?>"><br>
        </div>
        <div class="col-md-3">

                <label style="font-weight: 800;"><b> Nom </b></label><input class="form-control" type="text" name="name" value="<?php echo e($data->name); ?>"> <br>
        </div>

        <div class="col-md-3">
                <label style="font-weight: 800;"> <b>Cin</b></label><input class="form-control" type="text" name="cin" value ="<?php echo e($data->cin); ?>"><br>
        </div>
        <div class="col-md-5"> <label style="font-weight: 800;"><b>Tel</b></label><input name="tel"class="form-control" value="<?php echo e($data->tel); ?>"><br></div>
        <div class="col-md-5"><label style="font-weight: 800;"><b>Email</b></label><input type="email" class="form-control" name="email" value="<?php echo e($data->email); ?>"><br></div>
        <div class="col-md-6">
              <b><label style="font-weight: 800;">Changer votre photo</label><input type="file" class="form-control" name="imageurl"><br>
        <button name="enregistrer" class="btn btn-primary">Enregistrer</button>
        </div>
    </div>
</form>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebFinal1\resources\views/modifierProfil.blade.php ENDPATH**/ ?>