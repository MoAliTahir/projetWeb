<?php $__env->startSection('style'); ?>
    <style>
        .btn3{
            background-color: #ffc107;
            color: white;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div style="margin-top: 150px;"></div>
<div class="container form-group">
<h3> Modifier profil </h3> 

<form method="post" action="/updateclient" enctype="multipart/form-data">

    <input type="hidden" name="_method" value="PUT">

    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-md-3">
   <label> <b>login</b> </label><input type="text" class="form-control"  name="login" value="<?php echo e($data->login); ?>"><br>
        </div>
        <div class="col-md-3">

                <label><b> Nom </b></label><input class="form-control" type="text" name="name" value="<?php echo e($data->name); ?>"> <br>
        </div>

        <div class="col-md-3">
                <label> <b>Cin</b></label><input class="form-control" type="text" name="cin" value ="<?php echo e($data->cin); ?>"><br>
        </div>
        <div class="col-md-5"> <label><b>Tel</b></label><input name="tel"class="form-control" value="<?php echo e($data->tel); ?>"><br></div>
        <div class="col-md-5"><label><b>Email</b></label><input type="email" class="form-control" name="email" value="<?php echo e($data->email); ?>"><br></div>
        <div class="col-md-6">
              <b><label>Changer votre photo</label><input type="file" class="form-control" name="imageurl"><br>
        <button name="enregistrer" class="btn btn-primary">Enregistrer</button>
        </div>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nidal version\latestVersion3\projetWeb2\resources\views/client/modifierProfil.blade.php ENDPATH**/ ?>