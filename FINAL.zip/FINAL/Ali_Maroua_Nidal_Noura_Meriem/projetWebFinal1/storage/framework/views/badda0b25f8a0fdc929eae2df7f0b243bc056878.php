<?php $__env->startSection('titre'); ?>
    Acceuil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top: 80px">
        <center>
            <h3 style="margin-top: 30px;">Bienvenue sur <b>FastEasy</b></h3><br>

            <div class="col flex-center">
                <form class="form-inline shadow-none" method='post' action='/chercher' class="form-inline" >
                    <?php echo e(csrf_field()); ?>

                    <label for="ville" class="mr-sm-2">Ville</label>
                    <select name="ville" class="form-control mr-sm-4" id="ville" required="required">
                        <option value="null">--</option>
                        <option value="Agadir">Agadir</option>
                        <option value="Casablanca">Casablanca</option>
                        <option value="Rabat">Rabat</option>
                        <option value="Fes">Fes</option>
                        <option value="Sidi Kacem">Sidi kacem</option>
                        <option value="Sale">Sale</option>
                        <option value="Tetouan">Tetouan</option>
                        <option value="Tanger">Tanger</option>
                        <option value="Rabat">Rabat</option>
                        <option value="Meknes">Meknes</option>
                        <option value="Essaouira ">Essaouira </option>
                        <option value="Dakhla">Dakhla</option>
                    </select>

                    <label for="marque" class="mr-sm-2">Marque</label>
                    <select name="marque" class="form-control mr-sm-4" id="marque" required="required">
                        <option value="null">--</option>
                        <option value="Audi">Audi</option>
                        <option value="Range">Range</option>
                        <option value="Mercedes">Mercedes</option>
                        <option value="Kia">Kia</option>
                        <option value="Dacia">Dacia</option>
                        <option value=" Volkswagen">   Volkswagen</option>

                        <option value="BM">BM</option>
                        <option value="Firari">Firari</option>
                    </select>

                    <label for="date" class="mr-sm-2">Date de disponibilite</label>

                    <input type="date" name="date_debut" class="form-control mr-sm-4" required="required">


                    <button class="btn btn-outline-warning my-2 my-sm-0" type="submit" name="Rechercher">Rechercher</button>
                </form>
            </div>

        </center>
        <br><br><br>
         <div class="row" >
        <?php $__currentLoopData = $ann; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $an): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php   $v=\App\Voiture::find($an->id_voiture) ?><!--selectionner les info de voiture a l'aide de cle etrangere qui est dans annonce -->
                <?php   $Par=\App\User::find($an->id_partenaire) ?>
                <?php    $voiture_images2 = \App\Photo::all()->where("id_voiture", "=",$an->id_voiture)->first();?>

                <div class="col-md-4 zoom colonne " style="margin-bottom: 30px; " >
                    <div class="card" style="width: 18rem; height: 400px;border-radius: 5%;">

                            <img src="<?php echo e(asset('storage/'.$voiture_images2->chemin)); ?>" class="card-img-bottom img-fluid" alt="" style="height: 200px;border-radius: 5%;">

                        
                            
                            
                                
                            
                        
                            <div class="card-body">
                            <h5 class="card-title text-dark">Annonceur : <a href="/ProfilPartenaire/<?php echo e($Par->id); ?>"><?php echo e($Par->login); ?></a></h5>
                            <div class="card-text" style="margin:20px">
                                <table class="h6">
                                    <h7 class="card-title text-dark">Ville <?= $an->ville?></h7>
                                    <h5 class="card-title text-dark"> <?= $v['marque']?> <?= $v['type']." "; ?> </h5>
                                    <tr class="text-danger"><td>Prix/Heure :</td><td><?php echo e($an->prix); ?></td></tr>
                                </table>
                            </div>
                            <a href="/consulterAnnonce/<?php echo e($an->id); ?>" class="btn btn-primary">Consulter</a>
                            <a href="/reserverAnnonce/<?php echo e($an->id); ?>" class="btn btn-success">Reserver</a>

                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebMaroua\resources\views////welcome.blade.php ENDPATH**/ ?>