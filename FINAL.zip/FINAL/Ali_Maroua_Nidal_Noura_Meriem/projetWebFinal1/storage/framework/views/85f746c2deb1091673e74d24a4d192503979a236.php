
<?php $__env->startSection('content'); ?>
<h1>Mes reservations / nombre <?php echo e($data->count()); ?></h1>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <p>Date de reservations :<span><?php echo e($resev->date_reservation); ?></span></p>
    <p>Heure debut<span><?php echo e($resev->heureDebut); ?></span></p>
    <p>Heure fin<span><?php echo e($resev->heureFin); ?></span></p>
    <p>Prix<span><?php echo e($resev->prix); ?></span></p>

    <p><a href="client/mesReservations/voirAnnonce/<?php echo e($resev->id_annonce); ?>">voir Annonce </a></p>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb2/resources/views/client/mesReservations.blade.php ENDPATH**/ ?>