<?php $__env->startSection('titre'); ?>
  Consulter Annonce
    <?php $__env->stopSection(); ?>
  <?php if(isset(Auth::user()->statut)): ?>

<?php if(Auth::user()->statut === "admin"): ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php elseif(Auth::user()->statut === "partenaire"): ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

  <?php endif; ?>

<?php $__env->startSection('content'); ?>
       <div style="background-color: #E2E1EB; margin-top: -10px;">
<?php if(isset(Auth::user()->statut)): ?>
    <div class="container" style="margin-top: 150px; width: 100%; ">
<?php endif; ?>

<div id="carouselExampleIndicators" class="carousel slide"  data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" style="margin-left: 350px; margin-top: 50px;">
                <div class="carousel-item active">
                        <img class="d-block " height="350px"  width="500px" src="<?php echo e(asset('storage/'.$voiture_images2->chemin)); ?>" alt="First slide">
                </div>
                <?php  $table=array();
                        $i=0;
                foreach ($voiture_images as $image){
                    $table[$i++]=$image;
                    } ?>



              <?php for($j=1; $j < sizeof($table); $j++): ?>
              <div class="carousel-item">
              <img class="d-block"  height="350px"  width="500px" src="<?php echo e(asset('storage/'.$table[$j]->chemin)); ?>" alt="First slide">
              </div>
              <?php endfor; ?>

        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev" >
          <span class="carousel-control-prev-icon" aria-hidden="false" style="background-color:#2a3342;"></span>
          <span class="sr-only" style="">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon"  aria-hidden="false" style="background-color: #2a3342;"></span>
          <span class="sr-only">Next</span>
        </a>

    </div>
        <h3 style="font-size: 30px ; font-weight: 800; margin-top: 10px;"><center><?php echo e($v->marque); ?>  <?php echo e($v->type); ?></center></h3>
         <p><center>evaluation ..... etoiles..</center></p>



</center>

    <div style="margin:50px;" >


            <div class="row">
                <div class="col-md-5 shadow bb" style="background:white">
                    <p style="color: #2a3342; font-weight: 800;"><h5>INFORMATIONS SUR L'ANNONCE</h5></p>
                    <p><span style="font-size: 20px ; font-weight: 500"> Date de Debut:</span> <span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"><?php echo e($an1->date_debut); ?></span></p>
                    <p><span style="font-size: 20px ; font-weight: 500"> Heure de Debut:</span> <span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"><?php echo e($an1->heureDebut); ?></span></p>
                    <p ><span style="font-size: 20px ; font-weight: 500"> Date de Fin: </span><span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"> <?php echo e($an1->date_fin); ?></span></p>
                    <p> <span style="font-size: 20px ; font-weight: 500">Heure de Fin: </span><span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"><?php echo e($an1->heureFin); ?></span></p>
                    <p><span style="font-size: 20px ; font-weight: 500">Prix/Jour:</span> <span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"><?php echo e($an1->prix); ?> Dhs</span></p>
                </div>

            <div class="col-md-5 shadow bb" style="background:white; margin-left:170px;">
                <p style="color: #2a3342; font-weight: 800;"><h5>CARACTÉRISTIQUES TECHNIQUES</h5></p>
                 <p><span style="font-size: 20px ; font-weight: 500">Marque:</span><span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"><?php echo e($v->marque); ?></span></p>
                <p><span style="font-size: 20px ; font-weight: 500">Type:</span> <span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"><?php echo e($v->type); ?></span></p>
                 <p><span style="font-size: 20px ; font-weight: 500">Carburant:</span> <span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"><?php echo e($v->carburant); ?></span></p>
                <p><span style="font-size: 20px ; font-weight: 500">Nombre de places:</span> <span style="font-size: 21px; color: #1b4b72 ; font-weight: 800"><?php echo e($v->nbr_places); ?></span></p>
            </div>

        </div><br>

        <div style="background-color: white;" class="shadow bb"  >
            <p style="color: #2a3342; font-weight: 800;"><center><h5>PROPRIÉTAIRE</h5></center></p>


            <div> <center><a style="  text-decoration:none ; " href='/whoComments/<?php echo e($P->id); ?>'>
                        <img style="border-radius:50%; width:20%;"  src="<?php echo e(asset('storage/'.$P->chemin_image)); ?>">
                    </a> </center><br></div>
            <div> <center><a style="   text-decoration:none" href='/whoComments/<?php echo e($P->id); ?>'>
                        <strong style="font-size: 23px;"><?php echo e($P->login); ?></strong>
                    </a></center></div>



        </div>
        <br>

        <div class="row shadow" style="background-color: white;">
            <div class="col-md-10 " style=" margin-top:10px;">
                <h3>Commentaires sur la voiture</h3>
                <p style="color:#5a7391"><?php echo e($comment->count()); ?> commentaires</p>
                <hr>
                <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $who=\App\User::find($commentaire->id_from) ?>
                        <a style="color:blue;float:right;text-decoration:none" href="/whoComments/<?php echo e($who->id); ?>"><?php echo e($who->login); ?></a>
                        <a style="  text-decoration:none ; " href='/whoComments/<?php echo e($P->id); ?>'>
                                    <img border-radius="50%" width="20%" style="float: right; width: 30px; height: 30px;"  src="<?php echo e(asset('storage/'.$P->chemin_image)); ?>">
                                </a>

                    <p>   <img  src="<?php echo e(asset('storage/images/happy.png')); ?>" style="margin-right: 5px;width: 20px; height: 20px;"><span style="font-weight: 700"><?php echo e($commentaire->avisPositive); ?></span></p>
                        <p>   <img  src="<?php echo e(asset('storage/images/sad.png')); ?>" style="margin-right: 5px;width: 20px; height: 20px;"><span style="font-weight: 700"><?php echo e($commentaire->avisNegative); ?></span></p>
                    <p>note:<span><?php echo e($commentaire->note); ?></span></p>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        </div>

   </div>
       </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
            <style>
                .bb :hover{
                    box-shadow: 3px black;
                    cursor: pointer;

                }
            </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebFinal1\resources\views/consulterAnnonce.blade.php ENDPATH**/ ?>