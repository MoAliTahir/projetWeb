<?php $__env->startSection('titre'); ?>
    Acceuil
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <br><br><br><br><br><br>
    <div class="flex-center position-ref " style="background-color: #E2E1EB; margin: -145px -15px 0px -15px; padding-top: 180px;">

        <div class="content" style="background-color: #E2E1EB;">
            <form method='post' action='/chercher' class="form-group" >
                <?php echo e(csrf_field()); ?>


                <fieldset style="border: solid red 2px; padding: 20px 20px 20px 30px; background-color: white; width: 600px;" >
                   <legend style="font-weight: bold;font-size: 30px;color: #321655;">Trouver une voiture sur Fasteasy</legend>

                       <table >
                           <tr>
                               <th> Date Disponibilité:</th>
                               <th>Ville :</th>
                               <th>Marque:</th>
                           </tr>
                           <tr>
                           <td> <input type="date" name="date_debut" class="form-control"></td>

                               <td> <select name="ville" class="form-control">
                                       <option value="null">--</option>
                                       <option value="Agadir">Agadir</option>
                                       <option value="Casablanca">Casablanca</option>
                                       <option value="Rabat">Rabat</option>
                                       <option value="Fes">Fes</option>
                                       <option value="Sale">Sale</option>
                                       <option value="Tetouan">Tetouan</option>
                                       <option value="Tanger">Tanger</option>
                                       <option value="Rabat">Rabat</option>
                                       <option value="Meknes">Meknes</option>
                                       <option value="Essaouira ">Essaouira </option>
                                       <option value="Dakhla">Dakhla</option>
                                   </select></td>

                              <td>  <select name="marque" class="form-control">
                                      <option value="null">--</option>
                                    <option value="Range">Range</option>
                                    <option value="Mercedes">Mercedes</option>
                                    <option value="Kia">Kia</option>
                                    <option value="Dacia">Dacia</option>
                                    <option value="BM">BM</option>
                                    <option value="Firari">Firari</option>
                                    <option value="Audi">Audi</option>
                                </select></td>



                           </tr>
                       </table>
                    <input type="submit" value="Rechercher" class="btn btn-danger " style="margin-top:20px">

                </fieldset>
            </form>





        </div>
    </div>


         <div style="background-color: #E2E1EB; margin-left:-15px ; margin-right: -15px;">
    <div class="container" style="padding-top:0px ; background-color: #E2E1EB;">
        <div class="row" >
        <?php $__currentLoopData = $ann; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $an): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 	$v=\App\Voiture::find($an->id_voiture) ?><!--selectionner les info de voiture a l'aide de cle etrangere qui est dans annonce -->
                <?php 	$Par=\App\User::find($an->id_partenaire) ?>

                <div class="col-md-4 zoom colonne " style="margin-bottom: 30px; " >
                    <div class="card" style="width: 18rem; height: 400px;border-radius: 5%;">

                            <img src="<?php echo e(asset('storage/'.$v->chemin_image)); ?>" class="card-img-bottom img-fluid" alt="" style="height: 200px;border-radius: 5%;">

                        
                            
                            
                                
                            
                        
                            <div class="card-body">
                            <h5 class="card-title text-dark">Annonceur : <a href="/ProfilPartenaire/<?php echo e($Par->id); ?>"><?php echo e($Par->login); ?></a></h5>
                            <div class="card-text" style="margin:20px">
                                <table class="h6">
                                    <h5 class="card-title text-dark"> <?= $v['marque']?> <?= $v['type']." "; ?> </h5>
                                    <tr class="text-danger"><td>Prix/Heure :</td><td><?php echo e($an->prix); ?></td></tr>
                                </table>
                            </div>
                            <a href="/consulterAnnonce/<?php echo e($an->id); ?>" class="btn btn-primary">Consulter</a>
                            <a href="/reserverAnnonce/<?php echo e($an->id); ?>" class="btn btn-success">Reserver</a>

                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.publicTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWeb2\resources\views////welcome.blade.php ENDPATH**/ ?>