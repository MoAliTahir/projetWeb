<?php echo e($slot); ?>

<?php /**PATH /opt/lampp/htdocs/Laravel/Ali_Maroua_Nidal_Noura_Meriem/projetWebFinal1/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>