<?php $__env->startSection('content'); ?>

<form method="post" action="/update">

    <input type="hidden" name="_method" value="PUT">

    <?php echo e(csrf_field()); ?>


    Nom:<input name="name" value="<?php echo e($data->name); ?>"> <br>
    Email:<input name="email" value="<?php echo e($data->email); ?>"><br>
    Tel:<input name="tel" value="<?php echo e($data->tel); ?>"><br>
    Cin:<input name="cin" value ="<?php echo e($data->cin); ?>"><br>
    login:<input name="login" value="<?php echo e($data->login); ?>"><br>

    <button name="enregistrer">Enregistrer</button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWeb2\resources\views/modifierProfil.blade.php ENDPATH**/ ?>