<?php $__env->startSection('style'); ?>
    <style>
        .btn1{
            background-color: #ffc107;
            color: white;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div style="margin-top: 130px; background-color:  #E2E1EB; height: 100%; padding-top: 30px;">

    <div class="container ">
         <h2 style="margin-left: 300px;">Modifier l'annonce</h2>
          <div class="row">
              <div class="col-md-2"></div>
               <div class="col-md-7">
            <form action="<?php echo e(url('partenaire/modifierAnnonce/'.$annonce->id)); ?>" method="post" class="form-group" style="margin-left: 100px;">
            <input type="hidden" name="_method" value="PUT">
            <?php echo e(csrf_field()); ?>


                <label>DATE DE RETRAIT</label>
                <input class="form-control" type="date" name="date_debut" value="<?php echo e($annonce->date_debut); ?>">
                <br>
                <label>HEURE DE DEBUT</label>
                <input class="form-control" type="time" name="heureDebut" value="<?php echo e($annonce->heureDebut); ?>">
                <br>
                <label>DATE DE RETOUR</label>
                <input class="form-control" type="date" name="date_fin" value="<?php echo e($annonce->date_fin); ?>">
                <br>
                <label>HEURE DE RETOUR</label>
                <input class="form-control" type="time" name="heureFin" value="<?php echo e($annonce->heureFin); ?>">
                <br>
                <label>prix</label>
                <input class="form-control" type="number" name="prix" value="<?php echo e($annonce->prix); ?>">
                <br>

                <select name="id_voiture" class="form-control">

                    <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v['id'] == $annonce->id_voiture) { ?>
                        <option value="<?= $v['id'] ?>" selected>
                            <?= $v['type']." "; ?> <?= $v['marque']?>
                        </option>
                            <?php }  else {?>
                            <option value="<?= $v['id'] ?>">
                            <?= $v['type']." "; ?> <?= $v['marque']?>
                                <?php } ?>
                            </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <br>
                <input type="submit" value="Enregistrer" class="btn btn-success">
        </form>
          </div>
          </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebFinal1\resources\views/partenaire/modifierAnnonce.blade.php ENDPATH**/ ?>