<?php $__env->startSection('content'); ?>
            <div class="content" style="margin-top: 70px;padding-bottom: 70px">
                    <div class="title m-b-md">
                        Espase Administrateur
                    </div>

                    <div class="links">
                        <a href="#">Page1</a>
                        <a href="<?php echo e(Route('profil')); ?>">Mon Profil</a>
                        <a href="#">MPAge3</a>
                        <a href="#">mes notifications</a>
                        <a href="#">Page4</a>
                    </div>
            </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\projetWebMaroua\resources\views/homeAdmin.blade.php ENDPATH**/ ?>