<?php $__env->startSection('menu'); ?>

    <div style="margin-top: 115px;  position: fixed;
  top: 150px;
  height: 150px;
  width: 100%;
  z-index: 10;
  margin-top: -2.5em;">

        <div class="cc">
            <nav>
                <center>
                    <a href="#" >Accueil</a>
                    <a href="<?php echo e(Route('Annonce')); ?>" >Mes Annonces</a>
                    <a href="<?php echo e(Route('listVoiture')); ?>">Mes voitures</a>
                    <a href="<?php echo e(Route('profil')); ?>">Mon profil</a>
                    <a href="#">mes notifications</a>
                    <a href="<?php echo e(Route('nouvelAnnonce')); ?>">creer une annonce</a>
                    <div class="animation start-home"></div>
                </center>
            </nav>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div style="margin-top: 160px;"></div>
    <div class="container">
            <form action="<?php echo e(url('partenaire/modifierAnnonce/'.$annonce->id)); ?>" method="post" class="form-group">
            <input type="hidden" name="_method" value="PUT">
            <?php echo e(csrf_field()); ?>


                <label>DATE DE RETRAIT</label>
                <input class="form-control" type="date" name="date_debut" value="<?php echo e($annonce->date_debut); ?>">
                <br>
                <label>HEURE DE DEBUT</label>
                <input class="form-control" type="time" name="heureDebut" value="<?php echo e($annonce->heureDebut); ?>">
                <br>
                <label>DATE DE RETOUR</label>
                <input class="form-control" type="date" name="date_fin" value="<?php echo e($annonce->date_fin); ?>">
                <br>
                <label>HEURE DE RETOUR</label>
                <input class="form-control" type="time" name="heureFin" value="<?php echo e($annonce->heureFin); ?>">
                <br>
                <label>prix</label>
                <input class="form-control" type="number" name="prix" value="<?php echo e($annonce->prix); ?>">
                <br>

                <select name="id_voiture" class="form-control">

                    <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v['id'] == $annonce->id_voiture) { ?>
                        <option value="<?= $v['id'] ?>" selected>
                            <?= $v['type']." "; ?> <?= $v['marque']?>
                        </option>
                            <?php }  else {?>
                            <option value="<?= $v['id'] ?>">
                            <?= $v['type']." "; ?> <?= $v['marque']?>
                                <?php } ?>
                            </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <br>
                <input type="submit" value="Enregistrer" class="btn btn-success">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.publicTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\latestVersion3\projetWeb2\resources\views/partenaire/modifierAnnonce.blade.php ENDPATH**/ ?>