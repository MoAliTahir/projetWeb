<div style="height: 50px; background-color: #2a3342; position: fixed; top: 85px; width: 100%; z-index: 10">
    <div class="liens flex-center text-white">
        <a href="/home" class="bttn btn1">Accueil</a>|
        <a href="/profil" class="bttn btn2">Mon Profil</a>|
        <a href="client/mesReservations" class="bttn btn3">Mes reservations</a>|
        <a href="#" class="bttn btn4">Mes notifications</a>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LARAVEL\projetWebMaroua\resources\views/layouts/menuClient.blade.php ENDPATH**/ ?>