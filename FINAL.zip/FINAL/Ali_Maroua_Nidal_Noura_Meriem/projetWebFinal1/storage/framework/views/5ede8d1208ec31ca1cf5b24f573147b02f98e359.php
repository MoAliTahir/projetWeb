<?php $__env->startSection('style'); ?>
    <style>
        .btn2{
            background-color: #ffc107;
            color: white;
        }
        .btn2:hover{
            color: #2a3342;
        }
          /* style star*/

.clear{clear: both;}

.rate{
  width:225px; height: 40px;
  border:#e9e9e9 1px solid;
  background-color:  #f6f6f6;
  margin:60px auto;
  margin-bottom:0px;
}
.rate .rate-btn{
  width: 45px; height:40px;
  float: left;
  background: url("<?php echo e(asset('storage/images/rate-btn.png')); ?>") no-repeat;
  cursor: pointer;
}
.rate .rate-btn:hover, .rate  .rate-btn-hover, .rate  .rate-btn-active{
  background: url("<?php echo e(asset('storage/images/rate-btn-hover.png')); ?>") no-repeat;
}

.result-container{
  width: 82px; height: 18px;
  position: relative;
  background-color: #ccc;
  border: #ccc 1px solid;
  margin:auto;
}
.rate-stars{
  width: 82px; height: 18px;
  background-color:#ccc;
  background: url("<?php echo e(asset('storage/images/rate-stars.png')); ?>") no-repeat;
  position: absolute;
}
.rate-bg{
  height: 18px;
  background-color: #ffbe10;
  position: absolute;
}
/*fin style*/

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
body {
        background:#fafcfd;
        margin-bottom: 0;
    padding-bottom: 0;
      }
      .profile {
        margin: 20px 0;
      }
      .profile-sidebar {
        margin-top: 50px;
        height: 480px;
          width: 280px;
        padding: 20px 0 10px 0;
        background:lavender;
      }

      .profile-userpic img {
        float: none;
        margin: 0;
        width: 150px;
        height: 150px;
        border-radius: 50%;
      }

      .profile-usertitle {
        text-align: center;
        margin-top: 20px;
      }

      .profile-usertitle-name {
        color: #5a7391;
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 7px;
      }

      .profile-usertitle-job {
        text-transform: uppercase;
        color: #5b9bd1;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 15px;
      }


      /* Profile Content */
      .profile-content {
        margin-top: 50px;
          text-align: left;
        padding: 20px;
        background:lavender;
        min-height: 480px;
      }
     
    </style>

<div class="container" style="margin-top: 200px;">
        <div class="row profile">
            <div class="col-md-3">
                <div class="profile-sidebar">
                    <!-- SIDEBAR USERPIC -->
                    <center>
                        <div class="profile-userpic">
                            <img src="<?php echo e(asset('storage/'.$data->chemin_image)); ?>">
                         </div>
                    <!-- END SIDEBAR USERPIC -->
                    <!-- SIDEBAR USER TITLE -->
                        <div class="profile-usertitle">
                            <div class="profile-usertitle-name">
                               <h6><?php echo e($data->login); ?></h6>
                                <div class="profile-usertitle-job">
                                        <?php echo e($data->statut); ?>

                                </div>

                                <center>
                                <table>
                                   <tr><td> Nom: </td><td><?php echo e($data->name); ?></td></tr>
                                   <tr><td>CIN: </td><td><?php echo e($data->cin); ?></td></tr>
                                   <tr><td>Tel:</td><td><?php echo e($data->tel); ?></td></tr>
                                    <tr><td>Email: </td><td><?php echo e($data->email); ?></td></tr>
                               </table>
                                </center>

                            </div>

                        </div>
                        <!--noura-->
                    <img rel="icon" href="<?php echo e(asset('storage/images/notednndn.png')); ?>">
      <div class="box-result">
      <?php
      $idClient=Auth::user()->id;

      $query= App\CommentaireUser::all()->where('id_to','=',$idClient);
            foreach($query  as $data)
            {
             $rate_db[] = $data;
             $sum_rates[] = $data->note;

            }
                if(@count($rate_db)){
                    $rate_times = count($rate_db);
                    $sum_rates = array_sum($sum_rates);
                    $rate_value = $sum_rates/$rate_times;
                    $rate_bg = (($rate_value)/5)*100;
                }else{
                    $rate_times = 0;
                    $rate_value = 0;
                    $rate_bg = 0;
                }
        ?>
    <div class="result-container">
      <div class="rate-bg" style="width:<?php echo $rate_bg; ?>%"></div>
        <div class="rate-stars"></div>
    </div>
        <p style="margin:5px 0px; font-size:16px; text-align:center">Rated <strong><?php echo substr($rate_value,0,3); ?></strong> out of <?php echo $rate_times; ?> Review(s)</p>
    </div>
    <div class="profile-userbuttons">
                            <a href="/modifier" class="btn btn-danger btn-sm" >Modifier</a>
                    </div>
</div>
  <!--noura-->
                    <!-- END SIDEBAR USER TITLE -->
                    <!-- SIDEBAR BUTTONS -->
                   

                    </center>
                    <!-- END SIDEBAR BUTTONS -->
                    <!-- SIDEBAR MENU -->

                    <!-- END MENU -->
                    </div>
              
            <div class="col-md-9">
                <div class="profile-content">
                    <h3>les commentaires sur mon profil</h3>
                    <hr>
                    <?php $idUser=\Illuminate\Support\Facades\Auth::user()->id; ?>
                    <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php

                        $idResev=$resev->id;
                        $comments=\App\CommentaireUser::all()->where('id_reservation','=',$idResev);    ?>
                        <?php if($comments->count()>1): ?>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($commentaire->id_to ==$idUser ): ?>
                                    <?php $who=\App\User::find($commentaire->id_from) ?>
                                    <a style="color:blue;float:right;text-decoration:none" href="/whoComments/<?php echo e($who->id); ?>"><?php echo e($who->login); ?></a>
                                    <p>Avis Positive<span><?php echo e($commentaire->avisPositive); ?></span></p>
                                    <p>Avis Negative<span><?php echo e($commentaire->avisNegative); ?></span></p>
                                    <hr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\projetWebFinal1\projetWebFinal1\resources\views/client/profil.blade.php ENDPATH**/ ?>