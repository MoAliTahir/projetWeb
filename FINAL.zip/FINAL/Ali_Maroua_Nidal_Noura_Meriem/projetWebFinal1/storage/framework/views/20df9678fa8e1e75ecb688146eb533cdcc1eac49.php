<?php $__env->startSection('content'); ?>
            <div class="content">
                    <div class="title m-b-md">
                        Espase Partenaire
                    </div>

                    <div class="links">
                        <a href="#">Mes Annonces</a>
                        <a href="#">Mes voitures</a>
                        <a href="#">Mon profil</a>
                        <a href="#">mes notifications</a>
                        <a href="/Annonce/create/<?php echo e(Auth::user()->id); ?>">creer une annonce</a>
                    </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb/resources/views/homePartenaire.blade.php ENDPATH**/ ?>