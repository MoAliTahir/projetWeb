<?php if(Auth::user()->statut == "admin"): ?>
    <p> </p>
    <a href="/whoComments/<?php echo e($notification->data['Signalisation']['id_to']); ?>">le compte Signaler :</a>

<?php endif; ?>
<?php /**PATH C:\wamp\www\projetWebMaroua\resources\views/layouts/notification/notify_signaler.blade.php ENDPATH**/ ?>