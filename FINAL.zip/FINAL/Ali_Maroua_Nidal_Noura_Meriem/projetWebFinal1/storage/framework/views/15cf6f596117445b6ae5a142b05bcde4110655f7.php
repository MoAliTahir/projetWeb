<?php $__env->startSection('content'); ?>
<!doctype html>
<html>

<body style="background:#E8E8E8	">
    <center>
<div id="carouselExampleIndicators" class="carousel slide"  data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
                <div class="carousel-item active">
                        <img class="d-block " height="300px"  width="400px" src="<?php echo e(asset('storage/'.$voiture_images2->chemin)); ?>" alt="First slide">
                </div>
                <?php  $table=array();
                        $i=0;
                foreach ($voiture_images as $image){
                    $table[$i++]=$image;
                    } ?>



              <?php for($j=1; $j < sizeof($table); $j++): ?>
              <div class="carousel-item">
              <img class="d-block"  height="300px"  width="400px" src="<?php echo e(asset('storage/'.$table[$j]->chemin)); ?>" alt="First slide">
              </div>
              <?php endfor; ?>

        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="false"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon"  aria-hidden="false"></span>
          <span class="sr-only">Next</span>
        </a>

    </div>
        <h3><?php echo e($v->marque); ?>  <?php echo e($v->type); ?></h3>
        <p><?php echo e($v->nbr_places); ?> places</p>
         <p>evaluation ..... etoiles..</a>



</center>

    <div class="container" style="margin:50px;">
            <div class="row" >
                <div class="col-md-5 shadow" style="background:white; ">
                    <p style="color: selver">PROPRIÉTAIRE</p>
                     <a style=" shadow float:left; text-decoration:none" href='/whoComments/<?php echo e($P->id); ?>'>
                            <img border-radius="50%" width="20%"
                             src="<?php echo e(asset('storage/'.$P->chemin_image)); ?>">
                           <b> <?php echo e($P->login); ?><b>
                            </a>
                           <br>   <a style="float:left">evaluation .... ajouter.. etoiles..</a>

                           <br>
                </div>
            </div>
                <br>
            <div class="row">
                <div class="col-md-5 shadow" style="background:white">
                    <p>INFORMATIONS POUR RESERVATION</p>
                    <p> Date de Debut: <?php echo e($an1->date_debut); ?></p>
                        <p> Heure de Debut: <?php echo e($an1->heureDebut); ?></p>
                        <p > Date de Fin:  <?php echo e($an1->date_fin); ?></p>
                        <p> Heure de Fin: <?php echo e($an1->heureFin); ?></p>
                        <p>prix: <?php echo e($an1->prix); ?> Dhs</p>
                </div>

            <div class="col-md-5 shadow" style="background:white; margin-left:15px;">
                <p>CARACTÉRISTIQUES TECHNIQUES</p>
                 <p>marque:<?php echo e($v->marque); ?></p>
                <p>type: <?php echo e($v->type); ?></p>
                 <p>Carburant: </p><?php echo e($v->carburant); ?></p>
                <p>Nombre de places: <?php echo e($v->nbr_places); ?></p>
            </div>
            <div class="col-md-10 shadow" style="background:white; margin-top:10px;">
                    <h3>Evaluations</h3>
                    <p style="color:#5a7391"><?php echo e($comment->count()); ?> commentaires</p>
                    <hr>
                    <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $who=\App\User::find($commentaire->id_from) ?>
                <a style="color:blue;float:right;text-decoration:none" href="/whoComments/<?php echo e($who->id); ?>"><?php echo e($who->login); ?></a>
                <p><span><?php echo e($commentaire->commentaire); ?></span></p>
                        <p>note:<span><?php echo e($commentaire->note); ?></span></p>
<hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div>
        </div>

    </body>
    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\latestVersion3\projetWeb2\resources\views/consulterAnnonce.blade.php ENDPATH**/ ?>