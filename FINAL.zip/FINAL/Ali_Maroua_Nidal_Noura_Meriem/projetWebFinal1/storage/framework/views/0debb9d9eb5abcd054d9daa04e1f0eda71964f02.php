<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuPartenaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .btn1{
            background-color: #ffc107;
            color: white;
        }
        .btn1:hover{
            color: #2a3342;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
$annonces = App\Annonce::all()->where('id_partenaire', Auth::user()->id)->where('history','=',0);

?>
<?php echo $__env->make('partenaire.mesAnnonces', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/FINAL/projetWebFinal1/resources/views/homePartenaire.blade.php ENDPATH**/ ?>