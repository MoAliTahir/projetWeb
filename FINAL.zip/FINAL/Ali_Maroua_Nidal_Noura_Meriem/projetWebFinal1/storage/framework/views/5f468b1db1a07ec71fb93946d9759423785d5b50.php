<?php $__env->startSection('content'); ?>
    <div class="container">
    <h2 class="text-center">Vos annonces</h2>
    <br>
    <br>
        <div class="row">
        <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $an): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 	$v=\App\Voiture::find($an->id_voiture) ?><!--selectionner les info de voiture a l'aide de cle etrangere qui est dans annonce -->

                    <div class="col-md-4">
                        <div class="card" style="width: 18rem;">
                            <img src="<?php echo e(asset('storage/'.$v->chemin_image)); ?>" class="card-img-bottom" alt="">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">Statut : <?php echo e($an->statut); ?></h5>
                                    <div class="card-text" style="margin:20px">
                                        <table class="h6">		
                                            <tr><td>Modele :</td><td><?php echo e($v->modele); ?></td></tr>
                                            <tr><td>Marque :</td><td><?php echo e($v->marque); ?></td></tr>
                                            <tr><td>Date disponibilite :</td><td><?php echo e($an->date_annonce); ?></td></tr>
                                            <tr><td>Heure debut :</td><td><?php echo e($an->heureDebut); ?></td></tr>
                                            <tr><td>Heure fin :</td><td><?php echo e($an->heureFin); ?></td></tr>
                                            <tr class="text-danger"><td>Prix :</td><td><?php echo e($an->prix); ?></td></tr>
                                        </table>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <a href="<?php echo e(url('partenaire/modifierAnnonce/'.$an->id)); ?>" class="btn btn-primary">Modifier</a>
                                        </div>
                                        <div class="col-6">
                                        <form action="<?php echo e(url('/Annonce/'.$an->id)); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                        </div>
                                    </div>

                                </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>



        <ul>
                <li><a href="<?php echo e(Route('nouvelAnnonce')); ?>">creer une annonce</a></li>
                <li> <a href="/creerVoiture/<?php echo e(Auth::user()->id); ?>">nouvelle voiture</a></li>
        </ul>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb2/resources/views/partenaire/mesAnnonces.blade.php ENDPATH**/ ?>