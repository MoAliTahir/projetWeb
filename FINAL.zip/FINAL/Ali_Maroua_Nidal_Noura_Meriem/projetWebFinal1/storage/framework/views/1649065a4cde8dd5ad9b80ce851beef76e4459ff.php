<!doctype html>
<html>
<head>
</head>
<body>
<div class="container">

    <style>
        tr{
            border: 1px solid red;
        }
    </style>

    <p>Resultat de votre recherche :</p>


    <?php $__currentLoopData = $Resu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $var): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table class="table table-striped" style="border: 1px solid red;">
            <?php $voiture=\App\Voiture::find($var->id_voiture); ?>
            <tbody>
            <tr>
                <td>Ville:</td>
                <td><?php echo e($var->ville); ?></td>
            </tr>
            <tr>
                <td>Date Disponibilité: </td>
                <td><?php echo e($var->date_debut); ?></td>
            </tr>
            <tr>
                <td>Heure Debut:</td>
                <td><?php echo e($var->heureDebut); ?></td>
            </tr>
            <tr>
                <td>marque :</td>
                <td><?php echo e($voiture->marque); ?></td>
            </tr>
            <tr>
                <td>Nombre de places :</td>
                <td><?php echo e($voiture->nbr_places); ?></td>
            </tr>

            <tr>
                <td><a href=''><?php echo e(\App\User::find($var->id_partenaire)->login); ?></a></td>
                
            </tr>

            </tbody>

        </table></br>

        <hr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>
</body>
</html>
<?php /**PATH C:\wamp64\www\nidal version\latestVersion3\projetWeb2\resources\views/resultatRecherche.blade.php ENDPATH**/ ?>