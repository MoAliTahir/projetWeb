<?php $__env->startSection('content'); ?>

            <div class="content">
                    <div class="title m-b-md">
                        Espase Client
                    </div>

                    <div class="links">
                        <a href="#">Liste des annonces</a>
                        <a href="#">Mon Profil</a>
                        <a href="#">Mes reservations</a>
                        <a href="#">mes notifications</a>
                        <a href="#">Une autre Page</a>
                    </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\projet\projetWeb\resources\views/homeClient.blade.php ENDPATH**/ ?>