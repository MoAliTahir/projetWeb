<div style="height: 50px; background-color: #2a3342; position: fixed; top: 85px; width: 100%; z-index: 5">
    <div class="liens flex-center text-white">
        <a href="/home" class="bttn btn1">Accueil</a>|
        <a class="bttn btn3" href="<?php echo e(Route('listVoiture')); ?>">Mes voitures</a>|
        <a class="bttn btn4"  href="<?php echo e(Route('profil')); ?>">Mon profil</a>|
        <a class="bttn btn5" href="<?php echo e(Route('nouvelAnnonce')); ?>">creer une annonce</a>
        <div class="animation start-home"></div>
    </div>
</div>
<?php /**PATH C:\wamp\www\projetWebFinal1\projetWebFinal1\resources\views/layouts/menuPartenaire.blade.php ENDPATH**/ ?>