<?php $__env->startSection('content'); ?>
    <div class="flex-center position-ref">

        <div class="content">
            <form method='post' action='/chercher' class="form-group" style="width:500px">
                <?php echo e(csrf_field()); ?>


                <fieldset>
                    <legend class="h2">Trouver une voiture sur Fasteasy </legend>
                    <table>
                        <tr>
                            <td>Date Disponibilité: <input type="date" name="date_debut" class="form-control"></td>
                        </tr>
                        <tr>
                            <td>
                            <select class="form-control">
                                <option name="marque1">marque1</option>
                                <option  name="marque2">marque2</option>
                                <option  name="marque3">marque3</option>
                                <option name="marque4">marque4</option>
                                <option  name="marque5">marque5</option>
                            </select>
                            </td>

                        <td>
                            <select class="form-control">
                                <option name="ville" value="ville1">ville1</option>
                                <option  name="ville" value="ville2">ville2</option>
                                <option  name="ville" value="ville3">ville3</option>
                                <option name="ville" value="ville4">ville4</option>
                                <option  name="ville" value="ville5">ville5</option>
                            </select>
                        </td>
                        </tr>
                    </table>
                    <input type="submit" value="Rechercher" class="btn btn-danger" style="margin-top:20px">
                </fieldset>
            </form>

            <?php
            $ann = \App\Annonce::all()->sortByDesc('created_at');
            ?>



        </div>
    </div>



    <div class="container" style="padding-top:0px">
        <div class="row">
        <?php $__currentLoopData = $ann; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $an): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 	$v=\App\Voiture::find($an->id_voiture) ?><!--selectionner les info de voiture a l'aide de cle etrangere qui est dans annonce -->
                <?php 	$Par=\App\User::find($an->id_partenaire) ?>
                <div class="col-md-4">
                    <div class="card" style="width: 18rem;">
                        <img src="<?php echo e(asset('storage/'.$v->cheminImages)); ?>" class="card-img-bottom" alt="">
                        <div class="card-body">
                            <h5 class="card-title text-dark">Annonceur : <a href="/ProfilPartenaire/<?php echo e($Par->id); ?>"><?php echo e($Par->login); ?></a></h5>
                            <div class="card-text" style="margin:20px">
                                <table class="h6">
                                    <tr><td>Modele :</td><td><?php echo e($v->modele); ?></td></tr>
                                    <tr><td>Marque :</td><td><?php echo e($v->marque); ?></td></tr>
                                    <tr class="text-danger"><td>Prix :</td><td><?php echo e($an->prix); ?></td></tr>
                                </table>
                            </div>
                            <a href="/consulterAnnonce/<?php echo e($an->id); ?>" class="btn btn-primary">Consulter</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/projetWeb2/resources/views////welcome.blade.php ENDPATH**/ ?>