<?php if(Auth::user()->statut == "partenaire"): ?>
    <a  class="dropdown-item" href="/whoComments/<?php echo e($notification->data['reservation']['id_client']); ?>">Demande de reservation :</a>
    <a class="dropdown-item" href="/confirmer/<?php echo e($notification->data['reservation']['id']); ?>/<?php echo e($notification->data['reservation']['id_annonce']); ?>" name="confimer">confirmer</a>
    <a  class="dropdown-item" href="">Annuler</a>
<?php endif; ?>
<?php if(Auth::user()->statut == "client"): ?>
    <p>Felicitaion Votre reservation est confirmer </p>
<?php endif; ?>

<?php /**PATH C:\wamp\www\projetWebMeryem\resources\views/layouts/notification/notify_reser.blade.php ENDPATH**/ ?>