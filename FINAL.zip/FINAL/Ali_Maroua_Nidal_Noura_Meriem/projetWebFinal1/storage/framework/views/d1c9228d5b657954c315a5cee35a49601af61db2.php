<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div STYLE="background-color: #E2E1EB; margin-top: 120px;height: 100%; ">
        <div class="container">
            <h1 style="font-size: 70px; padding-top: 200px;padding-left: 100px; background-color: white;border-radius: 10px;" class="shadow" >ESPACE ADMINISTRATEUR</h1>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footer2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/FINAL/projetWebFinal1/resources/views/homeAdmin.blade.php ENDPATH**/ ?>