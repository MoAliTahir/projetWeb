<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Signalisation extends Model
{
    //
}
