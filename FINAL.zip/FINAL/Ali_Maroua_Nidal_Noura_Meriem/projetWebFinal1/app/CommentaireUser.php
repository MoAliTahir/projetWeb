<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommentaireUser extends Model
{
    //
}
