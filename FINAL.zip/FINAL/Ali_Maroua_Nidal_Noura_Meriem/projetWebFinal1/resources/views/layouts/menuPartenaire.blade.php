<div style="height: 50px; background-color: #2a3342; position: fixed; top: 85px; width: 100%; z-index: 5">
    <div class="liens flex-center text-white">
        <a href="/home" class="bttn btn1">Mes annonces</a>|
        <a class="bttn btn3" href="{{Route('listVoiture')}}">Mes voitures</a>|
        <a class="bttn btn7"  href="/profil">Mon profil</a>|
        <a class="bttn btn5" href="{{Route('nouvelAnnonce')}}">creer une annonce</a>
        <div class="animation start-home"></div>
    </div>
</div>
