@extends('layouts.template')
@section('style')
    <style>
        .btn5{
            background-color: #ffc107;
            color: white;
        }
        .btn5:hover{
            color: #2a3342;
        }

    </style>
@endsection
@section('menu')
    @include('layouts.menuPartenaire')
@endsection
@section('content')
    <div style="margin-top: 135px;padding-top: 20px; background-color: #E2E1EB ; ">
    <div class="container"  >

   <a href="{{url('partenaire/formVoiture')}}">  <button class="btn btn-success" style="float: right;">Ajouter Voiture</button></a>
    <br>
            <div class="row" style="height: 100%;">
        <div class="col-md-3" ></div>
        <div class="col-md-6">
            <form action="{{url('partenaire/createAnnonce')}}" method="post" class="form-group">
        {{ csrf_field() }}
            <input type="hidden" name="id" value="{{Auth::user()->id}}">


                <label style="font-weight: 800;">Ville</label>
                <select name="ville" class="form-control">
                    <option value="Agadir">Agadir</option>
                    <option value="Casablanca">Casablanca</option>
                    <option value="Rabat">Rabat</option>
                    <option value="Fes">Fes</option>
                    <option value="Sidi Kacem">Sidi Kacem</option>
                    <option value="Sale">Sale</option>
                    <option value="Tetouan">Tetouan</option>
                    <option value="Tanger">Tanger</option>
                    <option value="Rabat">Rabat</option>
                    <option value="Meknes">Meknes</option>
                    <option value="Essaouira ">Essaouira </option>
                    <option value="Dakhla">Dakhla</option>
                </select>
                <br>
                <label  style="font-weight: 800;" >DATE DE RETRAIT</label>
                <input class="form-control from-control-sm" type="date" name="date_debut">
                <br>
                <label  style="font-weight: 800;">HEURE DE RETRAIT</label>
                <input class="form-control from-control-sm"  type="time" name="heure_Debut">
                <br>
                <label  style="font-weight: 800;">DATE DE RETOUR</label>
                <input class="form-control from-control-sm" type="date" name="date_fin">
                <br>
                <label  style="font-weight: 800;">HEURE DE RETOUR</label>
                <input class="form-control from-control-sm" type="time" name="heure_fin">
                 <br>
                <label  style="font-weight: 800;">Voiture</label>
                <select class="form-control from-control-sm" name="id_voiture">
                <option value="--">--</option>
                @foreach($voiture as $v)
                <option value="<?= $v['id'] ?>">
                        <?= $v['type']." "; ?> <?= $v['marque']?>
                </option>
                @endforeach
            </select>
            <br>
            <label  style="font-weight: 800;">Prix/Heure</label>
            <input class="form-control from-control-sm" type="number" name="prix">
            <br>

        <input type="submit" value="Enregistrer" class="btn btn-success">
        </form>
        </div>
            </div>
        <br><br><br>
    </div>
    </div>
@endsection
