-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  mar. 14 mai 2019 à 00:12
-- Version du serveur :  10.1.38-MariaDB
-- Version de PHP :  7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `fasteasy3`
--

-- --------------------------------------------------------

--
-- Structure de la table `annonces`
--

CREATE TABLE `annonces` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_partenaire` int(10) UNSIGNED NOT NULL,
  `id_voiture` int(10) UNSIGNED NOT NULL,
  `heureDebut` time NOT NULL,
  `heureFin` time NOT NULL,
  `ville` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `prix` double NOT NULL,
  `statut` enum('disponible','reservé','traitement') COLLATE utf8mb4_unicode_ci NOT NULL,
  `history` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `annonces`
--

INSERT INTO `annonces` (`id`, `id_partenaire`, `id_voiture`, `heureDebut`, `heureFin`, `ville`, `date_debut`, `date_fin`, `prix`, `statut`, `history`, `created_at`, `updated_at`) VALUES
(3, 1, 17, '20:00:00', '15:00:00', 'Agadir', '2019-05-17', '2019-05-13', 500, 'reservé', 0, '2019-05-13 03:21:04', '2019-05-13 05:00:55'),
(4, 1, 24, '21:00:00', '10:00:00', 'Rabat', '2019-06-10', '2019-06-20', 500, 'disponible', 0, '2019-05-13 03:31:13', '2019-05-13 03:31:13'),
(5, 1, 22, '20:00:00', '12:00:00', 'Sidi Kacem', '2019-06-15', '2019-06-16', 800, 'disponible', 0, '2019-05-13 03:35:23', '2019-05-13 03:35:23'),
(6, 1, 23, '20:00:00', '14:28:00', 'Tanger', '2019-07-14', '2019-07-20', 1400, 'reservé', 0, '2019-05-13 03:36:23', '2019-05-13 10:51:40'),
(7, 1, 18, '05:00:00', '15:00:00', 'Meknes', '2019-07-10', '2019-07-15', 300, 'traitement', 0, '2019-05-13 03:39:09', '2019-05-13 17:47:17'),
(8, 1, 25, '14:00:00', '21:00:00', 'Agadir', '2019-05-14', '2019-05-16', 200, 'disponible', 0, '2019-05-13 03:41:48', '2019-05-13 03:41:48'),
(9, 1, 26, '21:00:00', '21:00:00', 'Dakhla', '2019-08-14', '2019-08-15', 700, 'disponible', 0, '2019-05-13 06:07:33', '2019-05-13 06:07:33');

-- --------------------------------------------------------

--
-- Structure de la table `commentaire_users`
--

CREATE TABLE `commentaire_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `avisPositive` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `avisNegative` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_reservation` int(10) UNSIGNED NOT NULL,
  `id_from` int(10) UNSIGNED NOT NULL,
  `id_to` int(10) UNSIGNED NOT NULL,
  `note` enum('1','2','3','4','5') COLLATE utf8mb4_unicode_ci NOT NULL,
  `history` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `commentaire_users`
--

INSERT INTO `commentaire_users` (`id`, `avisPositive`, `avisNegative`, `id_reservation`, `id_from`, `id_to`, `note`, `history`, `created_at`, `updated_at`) VALUES
(3, 'satisfait', 'retard', 1, 1, 4, '4', '0', NULL, NULL),
(4, 'super', 'tres mal', 1, 4, 1, '3', '0', NULL, NULL),
(5, 'jhhhhhh', 'bggbbb', 2, 1, 4, '5', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `commentaire_voitures`
--

CREATE TABLE `commentaire_voitures` (
  `id` int(10) UNSIGNED NOT NULL,
  `avisPositive` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `avisNegative` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_from` int(10) UNSIGNED NOT NULL,
  `id_to` int(10) UNSIGNED NOT NULL,
  `history` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` enum('1','2','3','4','5') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_04_24_152119_create_voitures_table', 1),
(4, '2019_04_24_153544_create_annonces_table', 1),
(5, '2019_04_24_160156_create_reservations_table', 1),
(6, '2019_04_24_160414_create_commentaire_users_table', 1),
(7, '2019_04_24_160531_create_commentaire_voitures_table', 1),
(8, '2019_04_28_185426_create_table_photos', 1),
(9, '2019_04_29_180228_create_notifications_table', 1),
(10, '2019_05_09_222019_create_signalisations_table', 1),
(11, '2019_05_10_164241_create_signalisationcs_table', 1),
(12, '2019_05_12_004730_create_signalisationcvs_table', 1),
(13, '2019_05_13_171420_ajout_notified_reservation', 2);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('0807485d-08f5-46e6-92c6-c1e8dec15952', 'App\\Notifications\\NotifyReser', 'App\\User', 1, '{\"reservation\":{\"id\":1,\"id_client\":4,\"statut\":0,\"id_annonce\":3,\"confirmer\":1,\"created_at\":\"2019-05-13 04:53:49\",\"updated_at\":\"2019-05-13 05:00:55\",\"notified\":0},\"url\":\"\\/evaluatePartenaire\\/1\\/4\"}', NULL, '2019-05-13 18:24:06', '2019-05-13 18:24:06'),
('0ecae335-b963-4638-b356-1bd66e816bda', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', NULL, '2019-05-13 10:51:45', '2019-05-13 10:51:45'),
('0f853e2f-2086-402c-86ce-60e738fb164f', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 15:28:13', '2019-05-13 13:12:38', '2019-05-13 15:28:13'),
('1899e9f4-0583-4285-81d0-ce3d42f64be7', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 15:28:26', '2019-05-13 13:04:44', '2019-05-13 15:28:26'),
('198c477e-b284-4ff1-badf-926c4041c85e', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 15:28:49', '2019-05-13 11:36:22', '2019-05-13 15:28:49'),
('2801d45d-e8ba-4b42-abff-dad64dc805eb', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 13:34:39', '2019-05-13 13:15:26', '2019-05-13 13:34:39'),
('3c1dc4fa-bf13-42b1-a45e-1eded18a09b2', 'App\\Notifications\\NotifySinalerC', 'App\\User', 8, '{\"Signalisation\":{\"id_from\":4,\"id_to\":\"4\",\"updated_at\":\"2019-05-13 13:34:58\",\"created_at\":\"2019-05-13 13:34:58\",\"id\":2}}', NULL, '2019-05-13 13:35:02', '2019-05-13 13:35:02'),
('443b192d-ffc0-41b3-b35e-a84172de589c', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 15:28:45', '2019-05-13 11:37:06', '2019-05-13 15:28:45'),
('749456ea-1458-45d5-b759-4d3c6e9344d9', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', NULL, '2019-05-13 11:35:11', '2019-05-13 11:35:11'),
('76c5e648-958c-4aa0-86c7-e4b36eaad5da', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 15:28:11', '2019-05-13 13:13:16', '2019-05-13 15:28:11'),
('7b1941c7-d0e6-4cf5-8f94-67a856e47efa', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 13:34:43', '2019-05-13 13:15:36', '2019-05-13 13:34:43'),
('7ca0e63d-551e-44c8-a828-cd96a93804e8', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 15:28:22', '2019-05-13 13:11:33', '2019-05-13 15:28:22'),
('8aa073d8-df59-4a15-ac84-ac0e8c71096e', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 15:28:05', '2019-05-13 13:13:25', '2019-05-13 15:28:05'),
('8c7bcd5c-8c5b-4835-88b8-15c9afb27df4', 'App\\Notifications\\NotifySignaler', 'App\\User', 8, '{\"Signalisation\":{\"id_from\":4,\"id_to\":\"1\",\"updated_at\":\"2019-05-13 06:14:52\",\"created_at\":\"2019-05-13 06:14:52\",\"id\":1}}', NULL, '2019-05-13 06:14:55', '2019-05-13 06:14:55'),
('931cf86a-20a5-48e9-b927-a5dd05caad85', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":1,\"id_client\":4,\"statut\":0,\"id_annonce\":3,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 04:53:49\",\"updated_at\":\"2019-05-13 05:00:55\"}}', NULL, '2019-05-13 05:00:57', '2019-05-13 05:00:57'),
('9495fa8a-3735-4ba4-a028-e0d5a75fddbb', 'App\\Notifications\\NotifyReser', 'App\\User', 1, '{\"reservation\":{\"id_client\":4,\"id_annonce\":3,\"updated_at\":\"2019-05-13 04:53:49\",\"created_at\":\"2019-05-13 04:53:49\",\"id\":1}}', NULL, '2019-05-13 04:53:52', '2019-05-13 04:53:52'),
('a1f80056-8915-4eab-845d-f91cf19e9fcd', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 13:34:46', '2019-05-13 13:14:01', '2019-05-13 13:34:46'),
('b11baebe-5e1a-488a-a803-5c39a2ebd175', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 15:27:49', '2019-05-13 13:13:51', '2019-05-13 15:27:49'),
('b8d0ff76-e88a-4454-b8cb-2bec204f7627', 'App\\Notifications\\NotifySinalerC', 'App\\User', 10, '{\"Signalisation\":{\"id_from\":1,\"id_to\":\"3\",\"updated_at\":\"2019-05-13 15:30:29\",\"created_at\":\"2019-05-13 15:30:29\",\"id\":4}}', '2019-05-13 15:31:06', '2019-05-13 15:30:29', '2019-05-13 15:31:06'),
('c48d63ef-c856-4177-b422-4e6b857db787', 'App\\Notifications\\NotifyReser', 'App\\User', 1, '{\"reservation\":{\"id_client\":4,\"id_annonce\":6,\"updated_at\":\"2019-05-13 05:32:09\",\"created_at\":\"2019-05-13 05:32:09\",\"id\":2}}', '2019-05-13 13:16:01', '2019-05-13 05:32:20', '2019-05-13 13:16:02'),
('c5467d7a-6b0d-4a29-a04a-f72b8d257af1', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":1,\"id_client\":4,\"statut\":0,\"id_annonce\":3,\"confirmer\":1,\"created_at\":\"2019-05-13 04:53:49\",\"updated_at\":\"2019-05-13 05:00:55\",\"notified\":0},\"url\":\"\\/evaluatePartenaire\\/4\\/1\"}', NULL, '2019-05-13 18:24:06', '2019-05-13 18:24:06'),
('c60175f4-c742-4387-af43-7f7b2542d38a', 'App\\Notifications\\NotifyReser', 'App\\User', 1, '{\"reservation\":{\"id_client\":2,\"id_annonce\":7,\"updated_at\":\"2019-05-13 17:47:18\",\"created_at\":\"2019-05-13 17:47:18\",\"id\":3},\"url\":null}', NULL, '2019-05-13 17:47:22', '2019-05-13 17:47:22'),
('c74cd982-6621-4ed1-8c3c-62d01d6252a3', 'App\\Notifications\\NotifySinalerC', 'App\\User', 8, '{\"Signalisation\":{\"id_from\":4,\"id_to\":\"4\",\"updated_at\":\"2019-05-13 06:13:35\",\"created_at\":\"2019-05-13 06:13:35\",\"id\":1}}', NULL, '2019-05-13 06:13:38', '2019-05-13 06:13:38'),
('e023d150-bcfa-4981-85c0-3208ddd10bac', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":1,\"id_client\":4,\"statut\":0,\"id_annonce\":3,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 04:53:49\",\"updated_at\":\"2019-05-13 05:00:55\"}}', NULL, '2019-05-13 05:59:07', '2019-05-13 05:59:07'),
('e48b6aeb-045e-4005-b4a1-8d66355f7370', 'App\\Notifications\\NotifySignaler', 'App\\User', 10, '{\"Signalisation\":{\"id_from\":4,\"id_to\":\"1\",\"updated_at\":\"2019-05-13 14:46:13\",\"created_at\":\"2019-05-13 14:46:13\",\"id\":3}}', '2019-05-13 15:31:26', '2019-05-13 14:46:14', '2019-05-13 15:31:26'),
('ed87ddac-d911-4a0d-8767-f10f9749de87', 'App\\Notifications\\NotifyReser', 'App\\User', 4, '{\"reservation\":{\"id\":2,\"id_client\":4,\"statut\":0,\"id_annonce\":6,\"confirmer\":\"1\",\"created_at\":\"2019-05-13 05:32:09\",\"updated_at\":\"2019-05-13 10:51:37\"}}', '2019-05-13 13:34:29', '2019-05-13 13:16:03', '2019-05-13 13:34:29'),
('f5f56529-15bf-490b-82af-24d2500a7bdb', 'App\\Notifications\\NotifySinalerC', 'App\\User', 10, '{\"Signalisation\":{\"id_from\":4,\"id_to\":\"4\",\"updated_at\":\"2019-05-13 13:48:20\",\"created_at\":\"2019-05-13 13:48:20\",\"id\":3}}', '2019-05-13 15:20:11', '2019-05-13 13:48:22', '2019-05-13 15:20:11'),
('fcc49f99-27d6-4698-b192-7b0ec24fb13e', 'App\\Notifications\\NotifySignaler', 'App\\User', 8, '{\"Signalisation\":{\"id_from\":4,\"id_to\":\"1\",\"updated_at\":\"2019-05-13 13:35:53\",\"created_at\":\"2019-05-13 13:35:53\",\"id\":2}}', NULL, '2019-05-13 13:35:53', '2019-05-13 13:35:53');

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `photos`
--

CREATE TABLE `photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `chemin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_voiture` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `photos`
--

INSERT INTO `photos` (`id`, `chemin`, `id_voiture`, `created_at`, `updated_at`) VALUES
(35, 'images/tzev5ilHwB5Xbk9KXtPAdvmsA62V7brACGizhZD4.jpeg', 17, '2019-05-13 01:46:54', '2019-05-13 01:46:54'),
(36, 'images/Qwao6H9xytBvnjXgL0Z0SpQijb5m3ye0TKwAwlOz.png', 17, '2019-05-13 01:46:54', '2019-05-13 01:46:54'),
(37, 'images/aQpgqv3D2bsOJxWBKAyhUUVDWCksM7hI41nO7yFY.jpeg', 17, '2019-05-13 01:46:54', '2019-05-13 01:46:54'),
(38, 'images/u4SGwkGEpVIAuuWHiMAeWKDXakig1NtWWNd9gP1i.jpeg', 18, '2019-05-13 03:22:25', '2019-05-13 03:22:25'),
(39, 'images/SQBsJNwqjFv4BNjYhdMajtLiVtfS36lciiIVEaPQ.jpeg', 18, '2019-05-13 03:22:25', '2019-05-13 03:22:25'),
(40, 'images/t8tIlaDwuT6zWXAR8Vwiy0sW7WTqOFa7Ofdovzat.webp', 18, '2019-05-13 03:22:25', '2019-05-13 03:22:25'),
(41, 'images/IsQXPqpcELPs0XXRdKKuH9UcwgnJgnfkfivMGsT1.jpeg', 22, '2019-05-13 03:26:40', '2019-05-13 03:26:40'),
(42, 'images/7yidqo6OkAQHKJSlw7a6UYWYMe3tWXE7SErB4ZSC.jpeg', 22, '2019-05-13 03:26:41', '2019-05-13 03:26:41'),
(43, 'images/uiX0ebDbfVgV9qmYdfGRijfg5AfPl8zm1VxTWqPN.jpeg', 22, '2019-05-13 03:26:41', '2019-05-13 03:26:41'),
(44, 'images/fOm2b56RybCUZIB74G3G8o9Vlerhoog9jQ1sWaDB.png', 23, '2019-05-13 03:27:27', '2019-05-13 03:27:27'),
(45, 'images/T4fzp968aAzV2UBTi7iczgnVmiq8MOgPAiiEc8em.jpeg', 23, '2019-05-13 03:27:27', '2019-05-13 03:27:27'),
(46, 'images/NXvPoPy8TMdFQxHqL8e6w0iqWn5HjkWJDH0tB2uV.jpeg', 23, '2019-05-13 03:27:27', '2019-05-13 03:27:27'),
(47, 'images/NuPDou4z7zOkhP8KwTW78YAM91QQUzO9JFpUnz3W.jpeg', 24, '2019-05-13 03:28:49', '2019-05-13 03:28:49'),
(48, 'images/0iAI72fAIBaplkiwPovsImTvX3TahMGQY4XTpiU2.jpeg', 24, '2019-05-13 03:28:50', '2019-05-13 03:28:50'),
(49, 'images/lWV2eLRXRcH9h2aNxUnhAXwZPeCdFDwbXKbWx55E.png', 24, '2019-05-13 03:28:50', '2019-05-13 03:28:50'),
(50, 'images/00ptzGXDmkY37duwgqAcGumRJoxMG1dmP32Ubf48.jpeg', 25, '2019-05-13 03:40:54', '2019-05-13 03:40:54'),
(51, 'images/LNWyxA410doIgL7HFoblqZWBSCU1GV0GcrRf71E1.jpeg', 25, '2019-05-13 03:40:54', '2019-05-13 03:40:54'),
(52, 'images/HvhWHJxlKxroLffijYwXtENRMoXNaO9w2s3tTtuQ.jpeg', 25, '2019-05-13 03:40:54', '2019-05-13 03:40:54'),
(53, 'images/i6gAkReOfcPSoh146MpF7iXvlCAssdcbT1m4DfOU.jpeg', 26, '2019-05-13 06:06:25', '2019-05-13 06:06:25'),
(54, 'images/o6aBIKqDutfJ24VyxnPBjldrc08OXeW4evo5npRr.jpeg', 26, '2019-05-13 06:06:25', '2019-05-13 06:06:25'),
(55, 'images/GHoGPYGtebqm64ODQBK35Z2FCQnVTJ8gkn10oZst.jpeg', 26, '2019-05-13 06:06:25', '2019-05-13 06:06:25');

-- --------------------------------------------------------

--
-- Structure de la table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_client` int(10) UNSIGNED NOT NULL,
  `statut` int(11) NOT NULL DEFAULT '0',
  `id_annonce` int(10) UNSIGNED NOT NULL,
  `confirmer` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `notified` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `reservations`
--

INSERT INTO `reservations` (`id`, `id_client`, `statut`, `id_annonce`, `confirmer`, `created_at`, `updated_at`, `notified`) VALUES
(1, 4, 0, 3, 1, '2019-05-13 04:53:49', '2019-05-13 18:24:06', 1),
(2, 4, 0, 6, 1, '2019-05-13 05:32:09', '2019-05-13 10:51:37', 0),
(3, 2, 0, 7, 0, '2019-05-13 17:47:18', '2019-05-13 17:47:18', 0);

-- --------------------------------------------------------

--
-- Structure de la table `signalisationcs`
--

CREATE TABLE `signalisationcs` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_from` int(10) UNSIGNED NOT NULL,
  `id_to` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `signalisationcs`
--

INSERT INTO `signalisationcs` (`id`, `id_from`, `id_to`, `created_at`, `updated_at`) VALUES
(1, 4, 4, '2019-05-13 06:13:35', '2019-05-13 06:13:35'),
(2, 4, 4, '2019-05-13 13:34:58', '2019-05-13 13:34:58'),
(3, 4, 4, '2019-05-13 13:48:20', '2019-05-13 13:48:20'),
(4, 1, 3, '2019-05-13 15:30:29', '2019-05-13 15:30:29');

-- --------------------------------------------------------

--
-- Structure de la table `signalisationcvs`
--

CREATE TABLE `signalisationcvs` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_from` int(10) UNSIGNED NOT NULL,
  `id_to` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `signalisations`
--

CREATE TABLE `signalisations` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_from` int(10) UNSIGNED NOT NULL,
  `id_to` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `signalisations`
--

INSERT INTO `signalisations` (`id`, `id_from`, `id_to`, `created_at`, `updated_at`) VALUES
(1, 4, 1, '2019-05-13 06:14:52', '2019-05-13 06:14:52'),
(2, 4, 1, '2019-05-13 13:35:53', '2019-05-13 13:35:53'),
(3, 4, 1, '2019-05-13 14:46:13', '2019-05-13 14:46:13');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chemin_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `history` int(11) NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `login`, `cin`, `tel`, `statut`, `chemin_image`, `history`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'maroua jellal', 'maroua@gmail.com', 'maroua', 'GK1481', '0676693089', 'partenaire', 'images/oty3ChBIWFey8SqPv8roXZ2jAwVpeqn2WrJXxerQ.jpeg', 0, NULL, '$2y$10$yy0WxVrcDyqLNq2DINWFpOrMuOBnG4LRjUC6uNAynN4qq/wFmMyti', NULL, '2019-05-12 21:43:23', '2019-05-13 01:22:32'),
(2, 'Ali tahir', 'ali@gmail.com', 'Ali', 'hj1458', '0632147892', 'client', 'images/hF88XA1cCyg6hjWL4fo9uyMcwiuPLYF5C6RuinhH.png', 0, NULL, '$2y$10$84kh6irqbZ2wmAuCJAPmPOV54DYTDlbvJsyVqaLrDSWazQPRvbA3e', NULL, '2019-05-12 21:46:04', '2019-05-12 21:46:04'),
(3, 'meryem beloughzal', 'meryem@gmail.com', 'meryem', 'FG1478', '0698201347', 'partenaire', 'images/hF88XA1cCyg6hjWL4fo9uyMcwiuPLYF5C6RuinhH.png', 0, NULL, '$2y$10$5X9B2M3aSL3oLfjKujnad.xmT/VumAoAJGJUjbMvCMejHpjDtXW6O', NULL, '2019-05-12 21:47:29', '2019-05-12 21:47:29'),
(4, 'nidal rahmouni', 'nidalRh@gmail.com', 'nidal', 'li1470', '0632147890', 'client', 'images/igoNMwy2SmOcCcQy9eU4gRTs44BNsQKzRFhXi92f.jpeg', 0, NULL, '$2y$10$dx6RzgAlXDmcJy9/IA83zu4VJvhBJGDz/VOn0OMkszR3PGQ8BDiAC', NULL, '2019-05-12 21:49:31', '2019-05-13 05:54:20'),
(5, 'manal amaray', 'manal@gmail.com', 'manal', 'kl4780', '0676693089', 'client', 'images/hF88XA1cCyg6hjWL4fo9uyMcwiuPLYF5C6RuinhH.png', 0, NULL, '$2y$10$skhOHFkaGINH7OiaFF0vG.MgOAuiBWY/26ds9NiNW2KPeF/l3uPC2', NULL, '2019-05-12 21:50:29', '2019-05-12 21:50:29'),
(6, 'ahmed tahiri', 'ahmed@gmail.com', 'ahmed', 'hm1489', '0676693089', 'partenaire', 'images/hF88XA1cCyg6hjWL4fo9uyMcwiuPLYF5C6RuinhH.png', 0, NULL, '$2y$10$O8eaaT8mRa.Si77nvno2R.8qu61Ngn0bkpVKaNozkOX2iYTN534IC', NULL, '2019-05-12 21:51:20', '2019-05-12 21:51:20'),
(7, 'aya amrani', 'aya@gmail.com', 'aya', 'NB1402', '0658920147', 'client', 'images/hF88XA1cCyg6hjWL4fo9uyMcwiuPLYF5C6RuinhH.png', 0, NULL, '$2y$10$ikcI4dEw4netlKbGj21fQOm0o3LpQs3hE6cADjjOmN/4OD5x8.sDG', NULL, '2019-05-12 21:52:22', '2019-05-12 21:52:22'),
(8, 'fatima', 'fatima@gmail.com', 'fatima', 'LK1598', '0676693089', 'client', 'images/hF88XA1cCyg6hjWL4fo9uyMcwiuPLYF5C6RuinhH.png', 0, NULL, '$2y$10$2fJAU5t2gDdJ.MNq/WQOv.sfwqTCiuMkOeYqznIFuHtFoAHztHX6i', NULL, '2019-05-12 21:53:16', '2019-05-12 21:53:16'),
(10, 'noura elmouden', 'noura@gmail.com', 'noura', 'GH1480', '0687101298', 'admin', 'images/V86rWuX38YPRzdBwRvcVQ72FvkJTECALX79IOQnc.jpeg', 0, NULL, '$2y$10$uZjG4a52DjD9ncm0BORQGOOQpSfUmIrPQR7Natzno7IMMUfaOJG1u', NULL, '2019-05-13 04:20:53', '2019-05-13 04:43:43');

-- --------------------------------------------------------

--
-- Structure de la table `voitures`
--

CREATE TABLE `voitures` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_partenaire` int(10) UNSIGNED NOT NULL,
  `type` enum('Coupé','Familiale','Cabriolet','Pickup','4x4','sport') COLLATE utf8mb4_unicode_ci NOT NULL,
  `marque` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `carburant` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nbr_places` int(11) NOT NULL,
  `history` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `voitures`
--

INSERT INTO `voitures` (`id`, `id_partenaire`, `type`, `marque`, `carburant`, `nbr_places`, `history`, `created_at`, `updated_at`) VALUES
(17, 1, 'Pickup', 'BM', 'Électrique', 3, 0, '2019-05-13 01:46:54', '2019-05-13 03:18:22'),
(18, 1, 'Familiale', 'Range', 'Électrique', 4, 0, '2019-05-13 03:22:22', '2019-05-13 03:22:22'),
(22, 1, 'Coupé', 'Mercedes', 'Diesel', 2, 0, '2019-05-13 03:26:39', '2019-05-13 03:26:39'),
(23, 1, 'Coupé', 'Range', 'Diesel', 2, 0, '2019-05-13 03:27:26', '2019-05-13 03:27:26'),
(24, 1, 'Cabriolet', 'Renault', 'Diesel', 3, 0, '2019-05-13 03:28:47', '2019-05-13 03:28:47'),
(25, 1, 'Coupé', 'Dacia', 'Essence', 4, 0, '2019-05-13 03:40:53', '2019-05-13 03:40:53'),
(26, 1, 'Cabriolet', 'Mercedes', 'Essence', 3, 0, '2019-05-13 06:06:23', '2019-05-13 06:06:23');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `annonces`
--
ALTER TABLE `annonces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `annonces_id_partenaire_foreign` (`id_partenaire`),
  ADD KEY `annonces_id_voiture_foreign` (`id_voiture`);

--
-- Index pour la table `commentaire_users`
--
ALTER TABLE `commentaire_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commentaire_users_id_reservation_foreign` (`id_reservation`),
  ADD KEY `commentaire_users_id_from_foreign` (`id_from`),
  ADD KEY `commentaire_users_id_to_foreign` (`id_to`);

--
-- Index pour la table `commentaire_voitures`
--
ALTER TABLE `commentaire_voitures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commentaire_voitures_id_from_foreign` (`id_from`),
  ADD KEY `commentaire_voitures_id_to_foreign` (`id_to`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Index pour la table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `photos_id_voiture_foreign` (`id_voiture`);

--
-- Index pour la table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reservations_id_client_foreign` (`id_client`),
  ADD KEY `reservations_id_annonce_foreign` (`id_annonce`);

--
-- Index pour la table `signalisationcs`
--
ALTER TABLE `signalisationcs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `signalisationcvs`
--
ALTER TABLE `signalisationcvs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `signalisations`
--
ALTER TABLE `signalisations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_login_unique` (`login`);

--
-- Index pour la table `voitures`
--
ALTER TABLE `voitures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `voitures_id_partenaire_foreign` (`id_partenaire`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `annonces`
--
ALTER TABLE `annonces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `commentaire_users`
--
ALTER TABLE `commentaire_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `commentaire_voitures`
--
ALTER TABLE `commentaire_voitures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT pour la table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `signalisationcs`
--
ALTER TABLE `signalisationcs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `signalisationcvs`
--
ALTER TABLE `signalisationcvs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `signalisations`
--
ALTER TABLE `signalisations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `voitures`
--
ALTER TABLE `voitures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `annonces`
--
ALTER TABLE `annonces`
  ADD CONSTRAINT `annonces_id_partenaire_foreign` FOREIGN KEY (`id_partenaire`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `annonces_id_voiture_foreign` FOREIGN KEY (`id_voiture`) REFERENCES `voitures` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `commentaire_users`
--
ALTER TABLE `commentaire_users`
  ADD CONSTRAINT `commentaire_users_id_from_foreign` FOREIGN KEY (`id_from`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commentaire_users_id_reservation_foreign` FOREIGN KEY (`id_reservation`) REFERENCES `reservations` (`id`),
  ADD CONSTRAINT `commentaire_users_id_to_foreign` FOREIGN KEY (`id_to`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `commentaire_voitures`
--
ALTER TABLE `commentaire_voitures`
  ADD CONSTRAINT `commentaire_voitures_id_from_foreign` FOREIGN KEY (`id_from`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commentaire_voitures_id_to_foreign` FOREIGN KEY (`id_to`) REFERENCES `voitures` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `photos`
--
ALTER TABLE `photos`
  ADD CONSTRAINT `photos_id_voiture_foreign` FOREIGN KEY (`id_voiture`) REFERENCES `voitures` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_id_annonce_foreign` FOREIGN KEY (`id_annonce`) REFERENCES `annonces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reservations_id_client_foreign` FOREIGN KEY (`id_client`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `voitures`
--
ALTER TABLE `voitures`
  ADD CONSTRAINT `voitures_id_partenaire_foreign` FOREIGN KEY (`id_partenaire`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
